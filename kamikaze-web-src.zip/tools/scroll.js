const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  const st = () => p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, items: __kr.menuItems().length }; });
  for (let i = 0; i < 40; i++) { await p.waitForTimeout(900); const s = await st(); if (s.u === 113) break; if (s.u === 118) await p.keyboard.press('Enter'); else if (s.bA !== -1 && !s.items && await p.isVisible('#ok')) await p.click('#ok'); else await p.mouse.click(420, 200); }
  const k = await p.evaluate(() => __kr.canvas.getBoundingClientRect()), sc = k.height / 240;
  const it = await p.evaluate(() => __kr.menuItems().find(q => q.i === 12));
  await p.mouse.click(k.left + (it.x + 5) * sc, k.top + (it.y + it.h / 2) * sc);   // click at the row's far left (outside the text)
  await p.waitForTimeout(2000); console.log(JSON.stringify(await st()));
  const sp = () => p.evaluate(() => { const w = __kr.widgets()[0]; return w ? w[0][27][0] : null; });
  console.log('start', await sp());
  const nb = await p.locator('#nd').boundingBox(); await p.mouse.move(nb.x + 10, nb.y + 10); await p.mouse.down();
  for (let i = 0; i < 4; i++) { await p.waitForTimeout(400); console.log('hold', await sp()); } await p.mouse.up(); await p.waitForTimeout(500);
  await p.mouse.move(k.left + 300, k.top + 150); for (let i = 0; i < 6; i++) await p.mouse.wheel(0, -120); await p.waitForTimeout(1500); console.log('wheel up', await sp());
  await p.mouse.move(k.left + 300, k.top + 100); await p.mouse.down(); for (let s = 1; s <= 10; s++) await p.mouse.move(k.left + 300, k.top + 100 - 12 * s); await p.mouse.up(); await p.waitForTimeout(1200); console.log('swipe', await sp());
  await b.close();
})();
