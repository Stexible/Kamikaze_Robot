const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  p.on('console', m => { if (m.type()==='error') console.log('[console]', m.text().slice(0,300)); });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html'); await p.waitForTimeout(3000);
  for (const [k, ms] of [['Enter',2000],['e',2500],['Enter',2000],['q',3000],['Enter',2500]]) { await p.keyboard.press(k); await p.waitForTimeout(ms); }
  // start a quick game so that player data exists, then jump to the chip screen
  await p.keyboard.press('Enter'); await p.waitForTimeout(2000); await p.keyboard.press('e'); await p.waitForTimeout(2000);
  await p.evaluate(() => { const D = __kr.D; console.log('before', D['u:I']); });
  const info = await p.evaluate(() => {
    const D = __kr.D; const e = D['e:[I'], h = D['h:[I'];
    window.__calls = [];
    return { e: e && Array.from(e), h: h && Array.from(h), u: D['u:I'] };
  });
  console.log('data', JSON.stringify(info));
  await p.evaluate(() => { const D = __kr.D; const e = D['e:[I']; e[5] = 4; e[6] = 3; e[0]=0;e[1]=0;e[2]=0;e[3]=0; D['G:I'] = 100; try { D['r()V'](); } catch (x) { console.log('r() failed', x.message); } D['g(I)V'](31); });
  await p.waitForTimeout(2500);
  console.log('state', JSON.stringify(await p.evaluate(() => __kr.state())));
  await p.screenshot({ path: `${S}/C0.png` });
  await p.keyboard.press('q'); await p.waitForTimeout(1500); await p.keyboard.press('q'); await p.waitForTimeout(6000);
  const rows = await p.evaluate(() => { const c=__kr.canvas.getBoundingClientRect(); return {c:[c.left,c.top,c.width,c.height]}; });
  console.log('canvas', JSON.stringify(rows), await p.evaluate(()=>document.getElementById('plus').className));
  const q = async () => console.log(JSON.stringify(await p.evaluate(() => ({ e: Array.from(__kr.D['e:[I']).slice(0,7) }))));
  await p.screenshot({ path: `${S}/C1.png` });
  // tap row 3 : row positions from screen: use logical y ~ rows
  const inf = await p.evaluate(() => { const c=__kr.canvas.getBoundingClientRect(); return {c:[c.left,c.top,c.width,c.height], s:__kr.rows&&__kr.rows()}; });
  console.log(JSON.stringify(inf));
  const R = inf.s; const cx = inf.c[0]+inf.c[2]/2, sc = inf.c[3]/240;
  const ry = r => inf.c[1]+(R[r][1]+R[r][3]/2)*sc;
  await p.mouse.click(cx, ry(2)); await p.waitForTimeout(800); await q();
  console.log('arrows', JSON.stringify(await p.evaluate(() => __kr.arrows())), 'cvs', JSON.stringify(inf.c));
  await p.screenshot({ path: `${S}/C1b.png` });
  const AR = await p.evaluate(() => __kr.arrows());
  if (AR.r) { const ax = inf.c[0] + (AR.r[0] + AR.r[2] / 2) * sc, ay = inf.c[1] + AR.r[1] * sc; await p.mouse.move(ax, ay); await p.mouse.down(); await p.waitForTimeout(700); await p.mouse.up(); await p.waitForTimeout(500); await q(); }
  const pb = await p.locator('#plus').boundingBox();
  await p.mouse.move(pb.x+pb.width/2, pb.y+pb.height/2); await p.mouse.down(); await p.waitForTimeout(700); await p.mouse.up(); await p.waitForTimeout(500); await q();
  const mb = await p.locator('#minus').boundingBox();
  await p.mouse.move(mb.x+mb.width/2, mb.y+mb.height/2); await p.mouse.down(); await p.waitForTimeout(300); await p.mouse.up(); await p.waitForTimeout(500); await q();
  await p.screenshot({ path: `${S}/C2.png` });
  for (let i=0;i<3;i++){ const pb2=await p.locator('#plus').boundingBox(); await p.mouse.move(pb2.x+9,pb2.y+9); await p.mouse.down(); await p.waitForTimeout(500); await p.mouse.up(); await p.waitForTimeout(400);} await q();
  const ob = await p.locator('#ok').boundingBox();
  await p.mouse.click(ob.x+ob.width/2, ob.y+ob.height/2); await p.waitForTimeout(1500);
  console.log('after OK', JSON.stringify(await p.evaluate(() => __kr.state())));
  await p.screenshot({ path: `${S}/C3.png` });
  await b.close();
})();
