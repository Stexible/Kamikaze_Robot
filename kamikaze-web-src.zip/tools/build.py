#!/usr/bin/env python3
"""Assemble dist/kamikaze.html (single self-contained page). Args: <extracted_jar_dir>"""
import sys, os, base64, json
jar = sys.argv[1]; root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
res = {}
for f in sorted(os.listdir(jar)):
    p = os.path.join(jar, f)
    if os.path.isfile(p) and not f.endswith('.class'):
        res['/' + f] = base64.b64encode(open(p, 'rb').read()).decode()
hires = {}
hd = os.path.join(root, 'res_hires')
if os.path.isdir(hd) and '--nohires' not in sys.argv:
    for f in sorted(os.listdir(hd)):
        if f.endswith('.png'): hires[f[:-4].split('__')[-1]] = base64.b64encode(open(os.path.join(hd, f), 'rb').read()).decode()
props = {}
for line in open(os.path.join(jar, 'META-INF/MANIFEST.MF')).read().splitlines():
    if ': ' in line:
        k, v = line.split(': ', 1); props[k] = v
game = open(os.path.join(root, 'dist/game.js')).read()
rt = open(os.path.join(root, 'src/rt.js')).read()
boot = open(os.path.join(root, 'src/boot.js')).read()
audio = open(os.path.join(root, 'src/audio.js')).read()
html = open(os.path.join(root, 'src/index.template.html')).read()
html = (html.replace('/*RT*/', rt).replace('/*GAME*/', 'window.$game=' + game + ';')
            .replace('/*RES*/', 'window.KR_RES=' + json.dumps(res) + ';window.KR_HIRES=' + json.dumps(hires) + ';window.KR_PROPS=' + json.dumps(props) + ';')
            .replace('/*AUDIO*/', audio).replace('/*BOOT*/', boot))
open(os.path.join(root, 'dist/kamikaze.html'), 'w').write(html)
print('wrote dist/kamikaze.html', len(html), 'bytes')
