const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  const st = () => p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, bC: s.bC, items: __kr.menuItems().length }; });
  for (let i = 0; i < 40; i++) { await p.waitForTimeout(900); const s = await st(); if (s.u === 113) break; if (s.u === 118) await p.keyboard.press('Enter'); else if (s.bA !== -1 && !s.items) await p.click('#ok'); else await p.keyboard.press('Enter'); }
  await p.keyboard.press('ArrowUp'); await p.waitForTimeout(400); await p.keyboard.press('Enter'); await p.waitForTimeout(1500);
  console.log('dlg', JSON.stringify(await st())); await p.screenshot({ path: `${S}/X1.png` });
  await p.click('#back'); await p.waitForTimeout(1500); console.log('No ->', JSON.stringify(await st()));
  await b.close();
})();
