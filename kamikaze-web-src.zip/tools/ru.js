const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  for (let i = 0; i < 15; i++) { await p.waitForTimeout(600); if ((await p.evaluate(() => __kr.state())).u === 118) break; }
  await p.waitForTimeout(800); await p.screenshot({ path: `${S}/${process.argv[4]||"R"}0.png` });
  const items = await p.evaluate(() => __kr.menuItems().map(i => [i.x, i.y, i.wd, i.h]));
  console.log(JSON.stringify(items));
  const c = await p.evaluate(() => { const r = __kr.canvas.getBoundingClientRect(); return [r.left, r.top, r.width / $rt_w()]; function $rt_w(){return 320} });
  const sc = await p.evaluate(() => __kr.canvas.getBoundingClientRect().height / 240);
  const L = items[+(process.argv[3]||items.length-1)];
  await p.mouse.click(__krLeft = (await p.evaluate(() => __kr.canvas.getBoundingClientRect().left)) + (L[0] + L[2] / 2) * sc, (L[1] + L[3] / 2) * sc);
  for (const t of [1500, 1500, 1500, 1500]) { await p.waitForTimeout(t); console.log(JSON.stringify(await p.evaluate(() => __kr.state()))); }
  await p.screenshot({ path: `${S}/${process.argv[4]||"R"}1.png` });
  await p.click('#ok'); 
  for (let i=0;i<24;i++){ await p.waitForTimeout(1200); const s=await p.evaluate(()=>__kr.state()); if (s.u===113) break; if (s.u===90||s.u===91) await p.click("#ok"); else await p.keyboard.press("Enter"); }
  await p.waitForTimeout(1000); await p.screenshot({ path: `${S}/${process.argv[4]||"R"}2.png` });
  const it = await p.evaluate(() => __kr.menuItems().map(i => [i.x, i.y, i.wd, i.h])); console.log(JSON.stringify(it));
  // open Instructions (guess last-ish items) -> tap second-to-last
  const k = await p.evaluate(() => __kr.canvas.getBoundingClientRect()); const sc2=k.height/240;
  const T = it[0]; await p.mouse.click(k.left+(T[0]+T[2]/2)*sc2, k.top+(T[1]+T[3]/2)*sc2); await p.waitForTimeout(2500); console.log(JSON.stringify(await p.evaluate(()=>__kr.state())));
  await p.screenshot({ path: `${S}/${process.argv[4]||"R"}3.png` });
  await b.close();
})();
