const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  for (let i = 0; i < 12; i++) { await p.waitForTimeout(700); const s = await p.evaluate(() => __kr.state()); if (s.bA !== -1 && s.bC !== -1) { console.log(JSON.stringify(s)); break; } if (s.u===118||s.bA===-1&&s.bC===-1) await p.keyboard.press('Enter'); }
  await p.waitForTimeout(800); await p.screenshot({ path: `${S}/Y.png` }); await b.close();
})();
