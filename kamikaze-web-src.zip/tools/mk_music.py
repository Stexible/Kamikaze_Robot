#!/usr/bin/env python3
"""Generate rhythmic chiptune-style MIDI tracks m0..m8 (one per tournament checkpoint) into <jar_dir>. Usage: mk_music.py <jar_dir> [--export <dir>]"""
import sys, os, random, struct

PPQ = 480; BAR = PPQ * 4; S16 = PPQ // 4
SC = {'minor': [0,2,3,5,7,8,10], 'dorian': [0,2,3,5,7,9,10], 'phrygian': [0,1,3,5,7,8,10],
      'mixo': [0,2,4,5,7,9,10], 'harm': [0,2,3,5,7,8,11], 'major': [0,2,4,5,7,9,11]}

def vlq(n):
    b = [n & 127]; n >>= 7
    while n: b.append((n & 127) | 128); n >>= 7
    return bytes(reversed(b))

class Track:
    def __init__(s, name): s.ev = []; s.name = name
    def note(s, t, d, n, v, ch): s.ev.append((t, 1, bytes([0x90 | ch, n, v]))); s.ev.append((t + max(d, 1), 0, bytes([0x80 | ch, n, 0])))
    def raw(s, t, b): s.ev.append((t, 0, b))
    def bytes(s):
        out = bytearray(b'\x00\xff\x03' + bytes([len(s.name)]) + s.name.encode()); last = 0
        for t, o, b in sorted(s.ev, key=lambda e: (e[0], e[1])):
            out += vlq(t - last) + b; last = t
        out += b'\x00\xff\x2f\x00'
        return b'MTrk' + struct.pack('>I', len(out)) + bytes(out)

def smf(tracks, bpm):
    t0 = Track('tempo'); t0.raw(0, b'\xff\x51\x03' + struct.pack('>I', int(60e6 / bpm))[1:]); t0.raw(0, b'\xff\x58\x04\x04\x02\x18\x08')
    allt = [t0] + tracks
    return b'MThd' + struct.pack('>IHHH', 6, 1, len(allt), PPQ) + b''.join(t.bytes() for t in allt)

def chord(scale, root, deg, size=3):
    out = []
    for k in range(size):
        d = deg + 2 * k; out.append(root + scale[d % 7] + 12 * (d // 7))
    return out

def drums(trk, bars, style, rng):
    for b in range(bars):
        t = b * BAR; fill = (b % 8 == 7)
        for i in range(16):
            tt = t + i * S16; beat = i % 4 == 0
            if style == 'four':      # four on the floor, offbeat open hats
                if i % 4 == 0: trk.note(tt, S16, 36, 112, 9)
                if i in (4, 12): trk.note(tt, S16, 38, 105, 9); trk.note(tt, S16, 39, 60, 9)
                if i % 4 == 2: trk.note(tt, S16, 46, 70, 9)
                elif i % 2 == 0 or i % 4 == 3: trk.note(tt, S16, 42, 45 + 15 * (i % 2 == 0), 9)
            elif style == 'break':   # syncopated breakbeat
                if i in (0, 10) or (i == 7 and b % 2) : trk.note(tt, S16, 36, 112, 9)
                if i in (4, 12): trk.note(tt, S16, 38, 108, 9)
                if i == 15 and b % 2: trk.note(tt, S16, 38, 60, 9)
                if i % 2 == 0: trk.note(tt, S16, 42, 70 if i % 4 else 90, 9)
                if i == 14: trk.note(tt, S16, 46, 65, 9)
            elif style == 'dnb':     # fast two-step
                if i in (0, 10): trk.note(tt, S16, 36, 115, 9)
                if i in (4, 12): trk.note(tt, S16, 38, 112, 9)
                if i in (7,) and b % 2: trk.note(tt, S16, 36, 80, 9)
                if i % 2 == 0: trk.note(tt, S16, 42, 55 + 20 * (i % 4 == 0), 9)
                if i in (15,): trk.note(tt, S16, 42, 50, 9)
            elif style == 'half':    # heavy half-time
                if i in (0, 6 if b % 2 else 8): trk.note(tt, S16, 36, 118, 9)
                if i == 8: trk.note(tt, S16, 38, 118, 9); trk.note(tt, S16, 39, 70, 9)
                if i % 2 == 0: trk.note(tt, S16, 42, 60 + 20 * beat, 9)
                if i in (13, 15) and b % 4 == 3: trk.note(tt, S16, 38, 70, 9)
            elif style == 'shuffle': # triplet-ish pushed groove expressed in 16ths
                if i in (0, 6, 10) : trk.note(tt, S16, 36, 112 if i == 0 else 90, 9)
                if i in (4, 12): trk.note(tt, S16, 38, 108, 9)
                if i % 3 == 0 and i < 15: trk.note(tt, S16, 42, 75, 9)
                elif i % 2 == 1: trk.note(tt, S16, 42, 40, 9)
            elif style == 'drive':   # rock-ish eighths
                if i in (0, 8) or (i == 10 and b % 2): trk.note(tt, S16, 36, 115, 9)
                if i in (4, 12): trk.note(tt, S16, 38, 112, 9)
                if i % 2 == 0: trk.note(tt, S16, 46 if i % 8 == 6 else 42, 85 if beat else 62, 9)
            if fill and i >= 12: trk.note(tt, S16, 38, 70 + (i - 12) * 15, 9)
        if b % 4 == 0: trk.note(t, S16, 49, 90, 9)   # crash on phrase start

def bassline(trk, bars, prog, root, scale, pattern, ch, rng):
    for b in range(bars):
        deg = prog[b % len(prog)]; r = root - 24 + scale[deg % 7] + 12 * (deg // 7); t = b * BAR
        fifth = r + 7
        for i in range(16):
            tt = t + i * S16
            if pattern == 'eighth':
                if i % 2 == 0: trk.note(tt, S16 * 2 - 20, r if i % 8 != 6 else fifth, 100 if i % 4 == 0 else 82, ch)
            elif pattern == 'octave':
                if i % 2 == 0: trk.note(tt, S16 * 2 - 20, r + (12 if i % 4 == 2 else 0), 100 if i % 4 == 0 else 85, ch)
            elif pattern == 'sync':
                if i in (0, 3, 6, 10, 12, 14): trk.note(tt, S16 * 2 - 20 if i != 14 else S16, r + (12 if i in (6, 14) else 0), 105 if i == 0 else 88, ch)
            elif pattern == 'sixteenth':
                if i % 4 != 3: trk.note(tt, S16 - 10, r + (12 if i % 8 == 5 else 0), 98 if i % 4 == 0 else 78, ch)
            elif pattern == 'walk':
                if i in (0, 4, 8, 12): trk.note(tt, S16 * 4 - 30, [r, r + 7 if True else r, r + 12, r + 7][(i // 4)], 100 if i == 0 else 85, ch)
                if i in (6, 14): trk.note(tt, S16, r + 12, 78, ch)
            elif pattern == 'pump':
                if i % 4 == 0: trk.note(tt, S16, r, 110, ch)
                if i % 4 == 2: trk.note(tt, S16, r + 12, 90, ch)

def arp(trk, bars, prog, root, scale, shape, ch, vel=70):
    shapes = {'up': [0, 1, 2, 3, 2, 1, 0, 1], 'zig': [0, 2, 1, 3, 2, 1, 3, 2], 'pulse': [0, 0, 2, 0, 1, 0, 2, 3], 'fan': [0, 1, 2, 3, 3, 2, 1, 0]}[shape]
    for b in range(bars):
        c = chord(scale, root + 12, prog[b % len(prog)], 3); c.append(c[0] + 12)
        for i in range(16):
            trk.note(b * BAR + i * S16, S16 - 15, c[shapes[i % 8]], vel + (12 if i % 4 == 0 else 0), ch)

def pad(trk, bars, prog, root, scale, ch, vel=48):
    for b in range(bars):
        for n in chord(scale, root, prog[b % len(prog)], 3): trk.note(b * BAR, BAR - 60, n, vel, ch)

MOTIFS = [[0, 3, 6, 8, 11, 14], [0, 2, 4, 8, 10, 12, 14], [0, 4, 6, 10, 12, 15], [0, 3, 4, 8, 11, 12, 14], [0, 2, 6, 7, 8, 12], [0, 6, 8, 10, 14, 16, 19, 22, 24, 28]]
def lead(trk, bars, prog, root, scale, ch, rng, hi=0, start_bar=0, gate=0.8):
    # two-bar motif repeated with chord-aware variations; steps are scale degrees
    rhy = [rng.choice(MOTIFS), rng.choice(MOTIFS)]
    steps = [[rng.choice([-2, -1, 1, 2, 1, -1, 3, -3]) for _ in range(12)] for _ in range(2)]
    for u in range(start_bar // 2, bars // 2):
        b = u * 2; deg = prog[b % len(prog)]; k = (u // 2) % 2
        pos = deg + 14 + (3 if u % 4 == 3 else 0)                       # start on a chord tone region
        pat = rhy[k] if u % 4 != 3 else rhy[0]
        for j, slot in enumerate(pat):
            if slot >= 32: continue
            pos = max(8, min(22, pos + steps[k][j % 12]))
            if slot % 16 == 0 or j == 0: pos = deg + 14 + [0, 2, 4][(u + j) % 3]       # land on chord tones on strong beats
            n = root + 12 * hi + scale[pos % 7] + 12 * (pos // 7) - 14 - 12 + 12
            nxt = pat[j + 1] if j + 1 < len(pat) else 32
            d = int((min(nxt, 32) - slot) * S16 * gate)
            trk.note(b * BAR + slot * S16, max(d, S16), n, 92 if slot % 8 == 0 else 78, ch)

def build(i, spec, rng):
    bpm, root, mode, progA, progB, ds, bs, ar, name = spec['bpm'], spec['root'], spec['mode'], spec['A'], spec['B'], spec['drums'], spec['bass'], spec['arp'], spec['name']
    scale = SC[mode]; bars = 16
    prog = progA * 1 + progB                                            # 8 bars A + 8 bars B, one chord per bar
    prog = (progA + progB)
    D = Track('drums'); drums(D, bars, ds, rng)
    B = Track('bass'); B.raw(0, bytes([0xC0 | 1, spec.get('bassprog', 38)])); bassline(B, bars, prog, root, scale, bs, 1, rng)
    A = Track('arp'); A.raw(0, bytes([0xC0 | 2, spec.get('arpprog', 80)])); arp(A, bars, prog, root, scale, ar, 2, vel=58)
    L = Track('lead'); L.raw(0, bytes([0xC0 | 3, spec.get('leadprog', 81)])); lead(L, bars, prog, root, scale, 3, rng, hi=spec.get('hi', 1), start_bar=2)
    P = Track('pad'); P.raw(0, bytes([0xC0 | 4, 89])); pad(P, bars, prog, root, scale, 4)
    for t, vol in ((B, 100), (A, 78), (L, 92), (P, 70)):
        ch = t.ev[0][2][0] & 15; t.ev.insert(0, (0, 0, bytes([0xB0 | ch, 7, vol])))
    return smf([D, B, A, L, P], bpm)

# 9 themes, one per tournament checkpoint (progressions are 4 bars of scale degrees, A then B)
THEMES = [
 dict(name='Meteors',   bpm=168, root=45, mode='minor',  A=[0,0,5,6,0,0,3,4], B=[5,5,3,3,6,6,4,4], drums='four',  bass='eighth',    arp='up'),
 dict(name='Moon',      bpm=150, root=50, mode='dorian', A=[0,3,0,4,0,3,6,4], B=[5,5,3,3,6,6,0,0], drums='half',  bass='sync',      arp='fan', hi=0),
 dict(name='Ships',     bpm=156, root=47, mode='mixo',   A=[0,0,6,6,3,3,4,4], B=[0,6,3,4,0,6,5,4], drums='drive', bass='octave',    arp='zig'),
 dict(name='Asteroids', bpm=174, root=43, mode='phrygian',A=[0,1,0,5,0,1,6,4], B=[0,0,1,1,5,5,6,6], drums='dnb',   bass='sixteenth', arp='pulse'),
 dict(name='Factory',   bpm=140, root=48, mode='harm',   A=[0,0,3,3,5,5,4,4], B=[0,3,5,4,0,3,6,4], drums='break', bass='pump',      arp='pulse', hi=0),
 dict(name='Turbines',  bpm=162, root=52, mode='minor',  A=[0,5,2,6,0,5,3,4], B=[3,3,4,4,0,0,5,6], drums='four',  bass='sixteenth', arp='fan'),
 dict(name='Railroad',  bpm=146, root=45, mode='mixo',   A=[0,0,3,3,4,4,0,0], B=[0,3,4,3,0,3,4,4], drums='shuffle',bass='walk',     arp='zig', hi=0),
 dict(name='Metropolis',bpm=158, root=46, mode='dorian', A=[0,6,5,6,0,6,5,4], B=[3,3,4,4,5,5,6,6], drums='break', bass='sync',      arp='up'),
 dict(name='Junkyard',  bpm=152, root=41, mode='phrygian',A=[0,0,1,1,0,0,5,6], B=[3,3,5,5,1,1,0,0], drums='half',  bass='octave',    arp='pulse', hi=0),
]
if __name__ == '__main__':
    jar = sys.argv[1]
    for i, th in enumerate(THEMES):
        data = build(i, th, random.Random(1000 + i * 77))
        open(os.path.join(jar, 'm%d' % i), 'wb').write(data)
        if '--export' in sys.argv:
            d = sys.argv[sys.argv.index('--export') + 1]; os.makedirs(d, exist_ok=True); open(os.path.join(d, '%d_%s.mid' % (i + 1, th['name'])), 'wb').write(data)
    print('ok', len(THEMES))
