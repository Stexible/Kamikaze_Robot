const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  for (let i = 0; i < 15; i++) { await p.waitForTimeout(600); if ((await p.evaluate(() => __kr.state())).u === 118) break; }
  await p.keyboard.press('Enter'); await p.waitForTimeout(1200); await p.click('#ok');
  for (let i=0;i<8;i++){ await p.waitForTimeout(1500); const s=await p.evaluate(()=>__kr.state()); if (s.u===113) break; await p.keyboard.press('Enter'); }
  await p.waitForTimeout(1000); await p.screenshot({ path: `${S}/E2.png` });
  const it = await p.evaluate(() => __kr.menuItems().map(i => [i.x, i.y, i.wd, i.h]));
  const k = await p.evaluate(() => __kr.canvas.getBoundingClientRect()); const sc2=k.height/240;
  const T = it[2]; await p.mouse.click(k.left+(T[0]+T[2]/2)*sc2, k.top+(T[1]+T[3]/2)*sc2); await p.waitForTimeout(2500); console.log(JSON.stringify(await p.evaluate(()=>__kr.state())));
  await p.screenshot({ path: `${S}/E3.png` });
  await b.close();
})();
