const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 }, hasTouch: true, isMobile: false });
  p.on('console', m => { const t = m.text(); if (!/^\[(java throw|js error)\]/.test(t)) console.log('[console]', m.type(), t.slice(0, 300)); });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 600)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html?touch=1');
  await p.waitForTimeout(3000);
  for (const [k, ms] of [['Enter',2000],['e',2500],['Enter',2000],['q',3000],['Enter',2500]]) { await p.keyboard.press(k); await p.waitForTimeout(ms); }
  await p.screenshot({ path: `${S}/R0.png` });
  await p.setViewportSize({ width: 390, height: 844 }); await p.waitForTimeout(1500);
  await p.screenshot({ path: `${S}/R1.png` });
  await p.keyboard.press('Enter'); await p.waitForTimeout(1500); await p.keyboard.press('q'); await p.waitForTimeout(3000);
  await p.screenshot({ path: `${S}/R2.png` });
  await p.setViewportSize({ width: 844, height: 390 }); await p.waitForTimeout(1500);
  await p.screenshot({ path: `${S}/R3.png` });
  await b.close();
})();
