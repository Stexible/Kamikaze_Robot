const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html' + (process.argv[3]||''));
  const st = () => p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, bC: s.bC, items: __kr.menuItems().length, c: __kr.D['c:I'] }; });
  let tapped = false;
  for (let i = 0; i < 60; i++) {
    await p.waitForTimeout(900); const s = await st();
    if (s.u === 113 && !tapped) { const it = await p.evaluate(() => __kr.menuItems()[2]); const k = await p.evaluate(() => __kr.canvas.getBoundingClientRect()); const sc=k.height/240; await p.mouse.click(k.left+(it.x+it.wd/2)*sc, k.top+(it.y+it.h/2)*sc); tapped = true; continue; }
    if (tapped && s.u !== 113) { console.log(i, JSON.stringify(s)); }
    if (s.u === 118) await p.keyboard.press('Enter');
    else if (s.bA !== -1 && s.items === 0 && s.u !== 113) await p.click('#ok');
    else if (s.u === 123 || s.u === 100) await p.click('#ok');
    else if (!tapped) await p.keyboard.press('Enter');
    if (tapped && i > 25) break;
  }
  await p.mouse.move(400,200); await p.mouse.down(); await p.waitForTimeout(400); console.log('mouse', JSON.stringify(await st())); await p.mouse.up();
  await p.keyboard.down('Space'); await p.waitForTimeout(500); console.log('space', JSON.stringify(await st())); await p.keyboard.up('Space');
  await p.screenshot({ path: `${process.argv[2]}/U.png` });
  await b.close();
})();
