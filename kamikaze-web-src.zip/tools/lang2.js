const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 844, height: 390 } }); const p = await ctx.newPage();
  const url = 'file:///home/claude/kamikaze-web/dist/kamikaze.html';
  await p.goto(url);
  const st = () => p.evaluate(() => __kr.state());
  for (let i = 0; i < 20; i++) { await p.waitForTimeout(600); if ((await st()).u === 118) break; }
  await p.keyboard.press('ArrowDown'); await p.waitForTimeout(300); await p.keyboard.press('Enter'); await p.waitForTimeout(1200);   // Русский
  for (let i = 0; i < 40; i++) { await p.waitForTimeout(700); const s = await st(); if (s.u === 117) { await p.click('#ok'); } else if (s.u === 113) break; else await p.mouse.click(420, 200); }
  console.log('lang1', await p.evaluate(() => __kr.E['b:[[Ljava/lang/String;'][__kr.D['f:[I'][2]][0]));
  await p.waitForTimeout(1500);
  await p.reload(); for (let i = 0; i < 40; i++) { await p.waitForTimeout(700); const s = await st(); if (s.u === 113) break; else await p.mouse.click(420, 200); }
  console.log('lang2 after reload', await p.evaluate(() => __kr.E['b:[[Ljava/lang/String;'][__kr.D['f:[I'][2]][0]));
  await b.close();
})();
