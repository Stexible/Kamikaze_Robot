const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  const st = () => p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, bC: s.bC, D: __kr.D['D:I'], C: __kr.D['C:I'], c: __kr.D['c:I'] }; });
  for (let i = 0; i < 40; i++) { await p.waitForTimeout(900); const s = await st(); if (s.u === 113) break; if (s.u === 118) await p.keyboard.press('Enter'); else if (s.bA !== -1) await (await p.isVisible('#ok') ? p.click('#ok') : p.mouse.click(420, 200)); else await p.keyboard.press('Enter'); }
  const open = async () => { const it = await p.evaluate(() => __kr.menuItems()[1]); const k = await p.evaluate(() => __kr.canvas.getBoundingClientRect()), sc = k.height / 240; await p.mouse.click(k.left + (it.x + it.wd / 2) * sc, k.top + (it.y + it.h / 2) * sc); };
  await open();
  for (let i = 0; i < 25; i++) { await p.waitForTimeout(1000); const s = await st(); if (s.u === 76 || s.u === 12) break; if (s.u === 123) await p.click('#back'); else if (s.bA !== -1) await (await p.isVisible('#ok') ? p.click('#ok') : p.mouse.click(420, 200)); }
  await p.evaluate(() => __kr.D['g(I)V'](113)); await p.waitForTimeout(2500);
  console.log('menu', JSON.stringify(await st())); await open();
  for (let i = 0; i < 20; i++) { await p.waitForTimeout(1200); const s = await st(); console.log(JSON.stringify(s)); if (s.u === 9) break; if (s.u === 123) await p.click('#back'); else if (s.bA !== -1) await (await p.isVisible('#ok') ? p.click('#ok') : p.mouse.click(420, 200)); }
  await p.evaluate(() => { const D = __kr.D; D['C:I'] = 0; D['D:I'] = 5; });
  await p.waitForTimeout(2500); await p.screenshot({ path: `${S}/K0.png` });
  for (const k of ['ArrowUp', 'ArrowUp', 'ArrowDown']) { await p.keyboard.down(k); await p.waitForTimeout(350); await p.keyboard.up(k); await p.waitForTimeout(2800); console.log(k, JSON.stringify(await st())); }
  await p.screenshot({ path: `${S}/K1.png` });
  console.log('ok visible', await p.isVisible('#ok'), 'nav', await p.isVisible('#nd'));
  await p.mouse.click(300, 120); await p.waitForTimeout(2500); console.log('after tap', JSON.stringify(await st()));
  await b.close();
})();
