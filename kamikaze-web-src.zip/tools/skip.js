const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 }, hasTouch: true });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  console.log('skip text:', await p.evaluate(() => __kr.E['c(I)Ljava/lang/String;'](131127)));
  const seen = new Set();
  for (let i = 0; i < 40; i++) {
    await p.waitForTimeout(700); const s = await p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, bC: s.bC, left: s.left, items: __kr.menuItems().length }; });
    const vis = await p.isVisible('#ok'); const key = s.u + '|' + s.left + '|' + vis; if (!seen.has(key)) { seen.add(key); console.log(JSON.stringify(s), 'okVisible', vis); }
    if (s.u === 113) break;
    if (s.u === 118) await p.keyboard.press('Enter'); else if (s.u === 117) await p.click('#ok'); else await p.touchscreen.tap(400, 200);
  }
  await b.close();
})();
