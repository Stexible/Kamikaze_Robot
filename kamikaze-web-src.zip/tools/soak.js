const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2], secs = +(process.argv[3] || 40);
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 960, height: 540 } });
  let errs = 0;
  p.on('console', m => { const t = m.text(); if (m.type() === 'error' || /unexpected|MISSING/.test(t)) { errs++; console.log('[console]', m.type(), t.slice(0, 400)); } });
  p.on('pageerror', e => { errs++; console.log('[pageerror]', String(e).slice(0, 600)); });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  await p.waitForTimeout(3000);
  for (const [k, ms] of [['Enter',2000],['e',2500],['Enter',2000],['q',3000],['e',2500],['Enter',2500],['Enter',2500],['Enter',2500],['Enter',2500]]) { await p.keyboard.press(k); await p.waitForTimeout(ms); }
  await p.screenshot({ path: `${S}/K0.png` });
  await p.evaluate(() => { $rt.perf.ms = 0; $rt.perf.n = 0; $rt.perf.max = 0; });
  const t0 = Date.now(); let i = 1;
  while (Date.now() - t0 < secs * 1000) {
    await p.keyboard.down('Enter'); await p.waitForTimeout(150 + Math.random() * 700); await p.keyboard.up('Enter'); await p.waitForTimeout(100 + Math.random() * 500);
    if (Math.random() < 0.05) await p.keyboard.press('q');
    if (i < 5 && (Date.now() - t0) > i * 8000) await p.screenshot({ path: `${S}/K${i++}.png` });
  }
  const perf = await p.evaluate(() => ({ ...$rt.perf, avg: $rt.perf.ms / $rt.perf.n }));
  console.log('perf', JSON.stringify(perf), 'errors', errs);
  await b.close();
})();
