const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('console', m => { if (m.type()==='warning') console.log('[w]', m.text().slice(0,200)); });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  const st = () => p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, items: __kr.menuItems().length }; });
  for (let i = 0; i < 40; i++) { await p.waitForTimeout(900); const s = await st(); if (s.u === 113) break; if (s.u === 118) await p.keyboard.press('Enter'); else if (s.bA !== -1 && !s.items) await p.click('#ok'); else await p.keyboard.press('Enter'); }
  console.log(await p.evaluate(() => { const w = __kr.D['k:[[Ljava/lang/Object;'][113]; return JSON.stringify({act: Array.from(w[21]), kinds: Array.from(w[15]), cap: w[27][29]}); }));
  await b.close();
})();
