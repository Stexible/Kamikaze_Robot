const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html'); await p.waitForTimeout(3000);
  console.log(JSON.stringify(await p.evaluate(() => { const s = atob(window.KR_RES['/u0']); const u = new Uint8Array(s.length); for (let k = 0; k < s.length; k++) u[k] = s.charCodeAt(k); const r = $rt.audio.parse(u); return [r.events.length, +r.dur.toFixed(1)]; })));
  const picks = await p.evaluate(() => { const E = __kr.E, out = []; for (let i = 0; i < 40; i++) { const r = E['a(I)[B'](131072); out.push(r.length); } return out; });
  console.log('sizes', [...new Set(picks)].join(','), 'counts', picks.filter(x => x > 5000).length, '/ 40 (extra track size ~', '?)');
  await b.close();
})();
