const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html'); await p.waitForTimeout(6000);
  console.log(JSON.stringify(await p.evaluate(() => window.__fonts), null, 0));
  await b.close();
})();
