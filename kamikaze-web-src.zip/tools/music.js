const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] }); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html'); await p.waitForTimeout(3000);
  console.log(JSON.stringify(await p.evaluate(() => { const out = []; for (let i = 0; i < 9; i++) { const s = atob(window.KR_RES['/m' + i]); const u = new Uint8Array(s.length); for (let k = 0; k < s.length; k++) u[k] = s.charCodeAt(k); const r = $rt.audio.parse(u); out.push([r.events.length, +r.dur.toFixed(1)]); } return out; })));
  // start tournament race, check which track is chosen and that audio plays
  const st = () => p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, items: __kr.menuItems().length }; });
  for (let i = 0; i < 40; i++) { await p.waitForTimeout(900); const s = await st(); if (s.u === 113) break; if (s.u === 118) await p.keyboard.press('Enter'); else if (s.bA !== -1 && !s.items && await p.isVisible('#ok')) await p.click('#ok'); else await p.keyboard.press('Enter'); }
  for (const r of (process.argv[2] === 't' ? [1] : [0, 1])) {
    const idx = r === 0 ? 3 : 4; // quick game / tournament
    const it = await p.evaluate(i => __kr.menuItems().find(q => q.i === i), idx), k = await p.evaluate(() => __kr.canvas.getBoundingClientRect()), sc = k.height / 240;
    await p.mouse.click(k.left + (it.x + it.wd / 2) * sc, k.top + (it.y + it.h / 2) * sc);
    for (let i = 0; i < 25; i++) { await p.waitForTimeout(1000); const s = await st(); if (s.u === 40 || s.u === 12 || s.u === 76) break; if (s.u === 123) await p.click('#back'); else if (s.bA !== -1 && await p.isVisible('#ok')) await p.click('#ok'); else await p.keyboard.press('Enter'); }
    await p.waitForTimeout(2500);
    console.log('mode', idx, 'track', await p.evaluate(() => window.__track), 'active', await p.evaluate(() => $rt.audio.active.size), JSON.stringify(await st()));
    await p.evaluate(() => __kr.D['g(I)V'](113)); await p.waitForTimeout(2500);
  }
  await b.close();
})();
