#!/usr/bin/env python3
"""Tiny JVM bytecode -> JavaScript translator (Java 1.3-era class files; ints, longs, refs, arrays).
Usage: jvm2js.py <classes_dir> <out.js>"""
import struct, sys, os, json

# ---------- class file parsing ----------
def mutf8(b):
    out=[]; i=0
    while i<len(b):
        c=b[i]
        if c<0x80: out.append(c); i+=1
        elif c&0xE0==0xC0: out.append(((c&0x1F)<<6)|(b[i+1]&0x3F)); i+=2
        else: out.append(((c&0x0F)<<12)|((b[i+1]&0x3F)<<6)|(b[i+2]&0x3F)); i+=3
    return ''.join(chr(x) for x in out)  # UTF-16 code units kept as chars (surrogates preserved)

class Cls: pass

def parse(data):
    p=0
    def u1():
        nonlocal p; v=data[p]; p+=1; return v
    def u2():
        nonlocal p; v=struct.unpack('>H',data[p:p+2])[0]; p+=2; return v
    def u4():
        nonlocal p; v=struct.unpack('>I',data[p:p+4])[0]; p+=4; return v
    assert u4()==0xCAFEBABE
    u2(); u2()
    n=u2(); cp=[None]*n; i=1
    while i<n:
        t=u1()
        if t==1:
            l=u2(); cp[i]=('utf8',mutf8(data[p:p+l])); p+=l
        elif t==3: cp[i]=('int',struct.unpack('>i',data[p:p+4])[0]); p+=4
        elif t==4: cp[i]=('float',struct.unpack('>f',data[p:p+4])[0]); p+=4
        elif t==5: cp[i]=('long',struct.unpack('>q',data[p:p+8])[0]); p+=8; i+=1
        elif t==6: cp[i]=('double',struct.unpack('>d',data[p:p+8])[0]); p+=8; i+=1
        elif t==7: cp[i]=('class',u2())
        elif t==8: cp[i]=('string',u2())
        elif t in (9,10,11): cp[i]=({9:'field',10:'method',11:'imethod'}[t],u2(),u2())
        elif t==12: cp[i]=('nat',u2(),u2())
        else: raise Exception('bad cp tag %d'%t)
        i+=1
    c=Cls(); c.cp=cp
    def utf(i): return cp[i][1]
    def cname(i): return utf(cp[i][1])
    c.utf=utf; c.cname=cname
    c.flags=u2(); c.name=cname(u2()); s=u2(); c.super=cname(s) if s else None
    c.ifaces=[cname(u2()) for _ in range(u2())]
    def attrs():
        out={}
        for _ in range(u2()):
            nm=utf(u2()); l=u4(); out[nm]=data[p:p+l]; skip(l)
        return out
    def skip(l):
        nonlocal p; p+=l
    c.fields=[]
    for _ in range(u2()):
        f=Cls(); f.flags=u2(); f.name=utf(u2()); f.desc=utf(u2()); f.attrs=attrs(); c.fields.append(f)
    c.methods=[]
    for _ in range(u2()):
        m=Cls(); m.flags=u2(); m.name=utf(u2()); m.desc=utf(u2()); m.attrs=attrs()
        m.code=None
        if 'Code' in m.attrs:
            b=m.attrs['Code']; q=0
            ms,ml,cl=struct.unpack('>HHI',b[0:8]); q=8
            code=b[q:q+cl]; q+=cl
            ne=struct.unpack('>H',b[q:q+2])[0]; q+=2
            exc=[]
            for _ in range(ne):
                s_,e_,h_,t_=struct.unpack('>HHHH',b[q:q+8]); q+=8
                exc.append((s_,e_,h_,cname(t_) if t_ else None))
            m.code=(ms,ml,code,exc)
        c.methods.append(m)
    c.attrs=attrs()
    return c

# ---------- helpers ----------
def js(s): return json.dumps(s, ensure_ascii=True)

def parse_desc(d):
    args=[]; i=1
    while d[i]!=')':
        j=i
        while d[j]=='[': j+=1
        if d[j]=='L': j=d.index(';',j)
        args.append(d[i:j+1]); i=j+1
    return args, d[i+1:]

def cat_of(t): return 2 if t in ('J','D') else 1

def default_of(t):
    return 'null' if t[0] in 'L[' else '0'

# opcode operand decode
def decode(code):
    ins=[]; p=0; n=len(code)
    while p<n:
        pc=p; op=code[p]; p+=1; a=()
        if op in (16,): a=(struct.unpack('>b',code[p:p+1])[0],); p+=1
        elif op==17: a=(struct.unpack('>h',code[p:p+2])[0],); p+=2
        elif op==18: a=(code[p],); p+=1
        elif op in (19,20): a=(struct.unpack('>H',code[p:p+2])[0],); p+=2
        elif op in (21,22,23,24,25,54,55,56,57,58,169): a=(code[p],); p+=1
        elif op==132: a=(code[p],struct.unpack('>b',code[p+1:p+2])[0]); p+=2
        elif 153<=op<=168 or op in (198,199): a=(pc+struct.unpack('>h',code[p:p+2])[0],); p+=2
        elif op==200: a=(pc+struct.unpack('>i',code[p:p+4])[0],); p+=4
        elif op==170:
            p=(p+3)&~3
            d,lo,hi=struct.unpack('>iii',code[p:p+12]); p+=12
            offs=struct.unpack('>%di'%(hi-lo+1),code[p:p+4*(hi-lo+1)]); p+=4*(hi-lo+1)
            a=(pc+d,lo,[pc+o for o in offs])
        elif op==171:
            p=(p+3)&~3
            d,npairs=struct.unpack('>ii',code[p:p+8]); p+=8
            pairs=[]
            for _ in range(npairs):
                k,o=struct.unpack('>ii',code[p:p+8]); p+=8; pairs.append((k,pc+o))
            a=(pc+d,pairs)
        elif op in (178,179,180,181,182,183,184,187,189,192,193): a=(struct.unpack('>H',code[p:p+2])[0],); p+=2
        elif op==185: a=(struct.unpack('>H',code[p:p+2])[0],code[p+2]); p+=4
        elif op==188: a=(code[p],); p+=1
        elif op==197: a=(struct.unpack('>H',code[p:p+2])[0],code[p+2]); p+=3
        elif op==196:
            op2=code[p]; p+=1
            if op2==132:
                a=(struct.unpack('>H',code[p:p+2])[0],struct.unpack('>h',code[p+2:p+4])[0]); p+=4; op=1132
            else:
                a=(struct.unpack('>H',code[p:p+2])[0],); p+=2; op=1000+op2
        ins.append((pc,op,a))
    return ins

BRANCH_IF1={153:'==',154:'!=',155:'<',156:'>=',157:'>',158:'<='}
BRANCH_IF2={159:'===',160:'!==',161:'<',162:'>=',163:'>',164:'<='}

class Compiler:
    def __init__(self, classes):
        self.classes=classes  # name -> Cls
        self.rt_refs={}       # (owner,key,kind) -> True
        self.rtcls={}         # rt class names used
        self.idx={}
    def is_game(self,n): return n in self.classes
    def cref(self,n):
        if n in self.classes:
            return 'C%d'%self.idx[n]
        if n.startswith('['): return '$rt.arrayClass(%s)'%js(n)
        self.rtcls[n]=True
        return 'R[%s]'%js(n)
    def find_field(self,owner,name,desc):
        o=owner
        while o in self.classes:
            c=self.classes[o]
            for f in c.fields:
                if f.name==name and f.desc==desc: return o,f
            # interfaces constants
            for i in c.ifaces:
                if i in self.classes:
                    r=self.find_field(i,name,desc)
                    if r[1]: return r
            o=c.super
        return None,None
    def find_method(self,owner,name,desc):
        o=owner
        while o in self.classes:
            c=self.classes[o]
            for m in c.methods:
                if m.name==name and m.desc==desc: return o,m
            o=c.super
        return None,None
    def mkey(self,owner,name,desc):
        d,m=self.find_method(owner,name,desc)
        k=name+desc
        if m is not None and (m.flags&2) and not (m.flags&8): k+='@'+d  # private instance method: no virtual override
        return k
    def fkey(self,owner,name,desc,static):
        d,f=self.find_field(owner,name,desc)
        if d is not None:
            return d, (name+':'+desc if static else d+'#'+name+':'+desc)
        return None, name+':'+desc

    def compile_class(self, c, out):
        i=self.idx[c.name]
        sup=c.super
        out.append('{')
        supexpr=self.cref(sup) if sup else 'null'
        ifs=json.dumps(c.ifaces)
        out.append('const K=C%d=$rt.defClass(%s,%s,%s,%d);'%(i,js(c.name),supexpr,ifs,c.flags))
        inst=[(d.name,d.desc) for d in c.fields if not d.flags&8]
        out.append('K.$fields=[%s];'%','.join('[%s,%s]'%(js(c.name+'#'+n+':'+t),default_of(t)) for n,t in inst))
        for f in c.fields:
            if f.flags&8:
                v=default_of(f.desc)
                if 'ConstantValue' in f.attrs:
                    ci=struct.unpack('>H',f.attrs['ConstantValue'])[0]; e=c.cp[ci]
                    if e[0] in ('int','long'): v=str(e[1])
                    elif e[0]=='string': v=js(c.utf(c.cp[ci][1]))
                    else: v=repr(e[1])
                out.append('K[%s]=%s;'%(js(f.name+':'+f.desc),v))
        has_clinit=any(m.name=='<clinit>' for m in c.methods)
        out.append('K.$hasClinit=%s;'%('true' if has_clinit else 'false'))
        for m in c.methods:
            if m.code is None: continue
            body=self.compile_method(c,m)
            static=bool(m.flags&8)
            if m.name=='<clinit>':
                out.append('K.$clinit=%s;'%body)
            elif static:
                out.append('K[%s]=%s;'%(js(m.name+m.desc),body))
            else:
                key=self.mkey(c.name,m.name,m.desc)
                out.append('K.prototype[%s]=%s;'%(js(key),body))
        out.append('}')

    def compile_method(self,c,m):
        ms,ml,code,exc=m.code
        static=bool(m.flags&8)
        args,ret=parse_desc(m.desc)
        params=[]; slot=0
        if not static: slot=1
        for a in args:
            params.append('l%d'%slot); slot+=cat_of(a)
        ins=decode(code)
        pcs=[x[0] for x in ins]
        byp={x[0]:k for k,x in enumerate(ins)}
        leaders={0}
        for pc,op,a in ins:
            if 153<=op<=168 or op in (198,199,200): leaders.add(a[0])
            if op==170: leaders.add(a[0]); leaders.update(a[2])
            if op==171: leaders.add(a[0]); leaders.update(t for _,t in a[1])
        for k,(pc,op,a) in enumerate(ins):
            if (153<=op<=168 or op in (170,171,172,173,174,175,176,177,191,198,199,200)) and k+1<len(ins): leaders.add(ins[k+1][0])
        for s_,e_,h_,t_ in exc:
            leaders.add(s_); leaders.add(h_)
            if e_ in byp: leaders.add(e_)
        order=sorted(leaders)
        blocks={}
        for k,l in enumerate(order):
            end=order[k+1] if k+1<len(order) else len(code)
            blocks[l]=[x for x in ins if l<=x[0]<end]
        entry={0:[]}
        for s_,e_,h_,t_ in exc: entry[h_]=[1]
        # propagate
        gen={}; work=[0]+[h for _,_,h,_ in exc]; seen=set()
        has_exc=bool(exc)
        while work:
            l=work.pop()
            if l in seen: continue
            seen.add(l)
            st=list(entry[l])
            lines,st2,succ,fall=self.gen_block(c,blocks[l],st,m,has_exc,l)
            gen[l]=lines
            for t,sstack in succ:
                if t not in entry: entry[t]=list(sstack)
                work.append(t)
            if fall is not None:
                nxt=order[order.index(l)+1] if order.index(l)+1<len(order) else None
                if nxt is not None:
                    if nxt not in entry: entry[nxt]=list(st2)
                    work.append(nxt)
        reach=[l for l in order if l in seen]
        nvars=ms+2
        head='function(%s){'%','.join(params)
        decl=[]
        if not static: decl.append('l0=this')
        for k in range(ml):
            if ('l%d'%k) not in params and not (k==0 and not static): decl.append('l%d'%k)
        decl+=['s%d'%k for k in range(ms+1)]+['t','t0','t1','t2','t3','t4','pc=0']
        s=head+'var '+','.join(decl)+';'
        single=(len(reach)==1)
        if single:
            s+='\n'.join(gen[reach[0]])
        else:
            s+='for(;;){'
            if has_exc: s+='try{'
            s+='switch(pc){'
            for l in reach:
                s+='case %d:'%l
                if has_exc: s+='pc=%d;'%l
                s+='\n'.join(gen[l])+'\n'
            s+='default:throw new Error("bad pc "+pc);}'
            if has_exc:
                s+='}catch(ex){ex=$rt.wrapEx(ex);'
                for s_,e_,h_,t_ in exc:
                    cond='pc>=%d&&pc<%d'%(s_,e_)
                    if t_: cond+='&&$rt.isInst(ex,%s)'%js(t_)
                    s+='if(%s){s0=ex;pc=%d;continue;}'%(cond,h_)
                s+='throw ex;}'
            s+='}'
        s+='}'
        return s

    def gen_block(self,c,instrs,st,m,has_exc,start):
        L=[]; succ=[]; fall=True
        def V(i): return 's%d'%i
        def push(cat): st.append(cat); return V(len(st)-1)
        def pop(): 
            st.pop(); return V(len(st))
        def topv(k=1): return V(len(st)-k)
        def emit(x): L.append(x)
        def guard_cls(n):
            if n in self.classes and self.classes[n].name!=c.name or (n in self.classes and False):
                if any(mm.name=='<clinit>' for mm in self.classes[n].methods) or self.has_clinit_super(n):
                    emit('if(!%s.$ok)%s.$init();'%(self.cref(n),self.cref(n)))
        def words(entries):
            return sum(entries)
        def dupgen(copy_w, skip_w):
            n=len(st); # find counts
            cw=0;ci=0
            while cw<copy_w: cw+=st[n-1-ci]; ci+=1
            sw=0;si=0
            while sw<skip_w: sw+=st[n-ci-1-si]; si+=1
            base=n-ci-si
            idxs=list(range(n-ci,n))+list(range(base,n-ci))+list(range(n-ci,n))
            cats=[st[i] for i in idxs]
            for k,i in enumerate(idxs): emit('t%d=s%d;'%(k,i))
            del st[base:]
            for k,ca in enumerate(cats):
                st.append(ca); emit('s%d=t%d;'%(len(st)-1,k))
        cp=c.cp
        def mref(idx):
            e=cp[idx]; owner=c.cname(e[1]); nat=cp[e[2]]; return owner,c.utf(nat[1]),c.utf(nat[2])
        for pc,op,a in instrs:
            if op==0: pass
            elif op==1: emit('%s=null;'%push(1))
            elif 2<=op<=8: emit('%s=%d;'%(push(1),op-3))
            elif op in (9,10): emit('%s=%d;'%(push(2),op-9))
            elif op==16 or op==17: emit('%s=%d;'%(push(1),a[0]))
            elif op in (18,19,20):
                e=cp[a[0]]
                if e[0]=='int': emit('%s=%d;'%(push(1),e[1]))
                elif e[0]=='string': emit('%s=%s;'%(push(1),js(c.utf(e[1]))))
                elif e[0]=='long': emit('%s=%d;'%(push(2),e[1]))
                elif e[0]=='float': emit('%s=%r;'%(push(1),e[1]))
                elif e[0]=='double': emit('%s=%r;'%(push(2),e[1]))
                else: raise Exception('ldc '+e[0])
            elif op in (21,23,25): emit('%s=l%d;'%(push(1),a[0]))
            elif op in (22,24): emit('%s=l%d;'%(push(2),a[0]))
            elif 26<=op<=29: emit('%s=l%d;'%(push(1),op-26))
            elif 30<=op<=33: emit('%s=l%d;'%(push(2),op-30))
            elif 42<=op<=45: emit('%s=l%d;'%(push(1),op-42))
            elif op in (46,50,51,52,53,47):
                i=pop(); ar=pop(); r=push(2 if op==47 else 1)
                emit('%s=%s[%s];if(%s===undefined)$rt.aioobe(%s,%s);'%(r,ar,i,r,ar,i))
            elif op in (54,56,58): emit('l%d=%s;'%(a[0],pop()))
            elif op in (55,57): emit('l%d=%s;'%(a[0],pop()))
            elif 59<=op<=62: emit('l%d=%s;'%(op-59,pop()))
            elif 63<=op<=66: emit('l%d=%s;'%(op-63,pop()))
            elif 75<=op<=78: emit('l%d=%s;'%(op-75,pop()))
            elif op in (79,80,83,84,85,86):
                v=pop(); i=pop(); ar=pop()
                emit('if(%s>>>0>=%s.length)$rt.aioobe(%s,%s);%s[%s]=%s;'%(i,ar,ar,i,ar,i,v))
            elif op==87: pop()
            elif op==88:
                w=0
                while w<2: w+=st.pop()
            elif op==89: dupgen(1,0)
            elif op==90: dupgen(1,1)
            elif op==91: dupgen(1,2)
            elif op==92: dupgen(2,0)
            elif op==93: dupgen(2,1)
            elif op==94: dupgen(2,2)
            elif op==95:
                emit('t=%s;%s=%s;%s=t;'%(topv(1),topv(1),topv(2),topv(2)))
            elif op==96: b=pop(); a_=topv(); emit('%s=(%s+%s)|0;'%(a_,a_,b))
            elif op==97: b=pop(); a_=topv(); emit('%s=$rt.ladd(%s,%s);'%(a_,a_,b))
            elif op==100: b=pop(); a_=topv(); emit('%s=(%s-%s)|0;'%(a_,a_,b))
            elif op==101: b=pop(); a_=topv(); emit('%s=$rt.lsub(%s,%s);'%(a_,a_,b))
            elif op==104: b=pop(); a_=topv(); emit('%s=Math.imul(%s,%s);'%(a_,a_,b))
            elif op==105: b=pop(); a_=topv(); emit('%s=$rt.lmul(%s,%s);'%(a_,a_,b))
            elif op==108: b=pop(); a_=topv(); emit('if(%s===0)$rt.div0();%s=(%s/%s)|0;'%(b,a_,a_,b))
            elif op==109: b=pop(); a_=topv(); emit('if(%s===0)$rt.div0();%s=Math.trunc(%s/%s);'%(b,a_,a_,b))
            elif op==112: b=pop(); a_=topv(); emit('if(%s===0)$rt.div0();%s=(%s%%%s)|0;'%(b,a_,a_,b))
            elif op==113: b=pop(); a_=topv(); emit('if(%s===0)$rt.div0();%s=%s%%%s;'%(b,a_,a_,b))
            elif op==116: a_=topv(); emit('%s=(-%s)|0;'%(a_,a_))
            elif op==117: a_=topv(); emit('%s=-%s;'%(a_,a_))
            elif op==120: b=pop(); a_=topv(); emit('%s=%s<<%s;'%(a_,a_,b))
            elif op==122: b=pop(); a_=topv(); emit('%s=%s>>%s;'%(a_,a_,b))
            elif op==124: b=pop(); a_=topv(); emit('%s=(%s>>>%s)|0;'%(a_,a_,b))
            elif op==126: b=pop(); a_=topv(); emit('%s=%s&%s;'%(a_,a_,b))
            elif op==128: b=pop(); a_=topv(); emit('%s=%s|%s;'%(a_,a_,b))
            elif op==130: b=pop(); a_=topv(); emit('%s=%s^%s;'%(a_,a_,b))
            elif op in (121,123,125,127,129,131):
                nm={121:'lshl',123:'lshr',125:'lushr',127:'land',129:'lor',131:'lxor'}[op]
                b=pop(); a_=topv(); emit('%s=$rt.%s(%s,%s);'%(a_,nm,a_,b))
            elif op==132 or op==1132: emit('l%d=(l%d+%d)|0;'%(a[0],a[0],a[1]))
            elif op==133: st[-1]=2
            elif op==136: v=topv(); st[-1]=1; emit('%s=%s|0;'%(v,v) if False else '%s=$rt.l2i(%s);'%(v,v))
            elif op==145: v=topv(); emit('%s=%s<<24>>24;'%(v,v))
            elif op==146: v=topv(); emit('%s=%s&65535;'%(v,v))
            elif op==147: v=topv(); emit('%s=%s<<16>>16;'%(v,v))
            elif op==148: b=pop(); a_=topv(); st[-1]=1; emit('%s=%s<%s?-1:(%s>%s?1:0);'%(a_,a_,b,a_,b))
            elif op in BRANCH_IF1:
                v=pop(); emit('if(%s%s0){pc=%d;continue;}'%(v,BRANCH_IF1[op],a[0])); succ.append((a[0],list(st)))
            elif op in BRANCH_IF2:
                b=pop(); a_=pop(); emit('if(%s%s%s){pc=%d;continue;}'%(a_,BRANCH_IF2[op],b,a[0])); succ.append((a[0],list(st)))
            elif op in (165,166):
                b=pop(); a_=pop(); emit('if(%s%s%s){pc=%d;continue;}'%(a_,'===' if op==165 else '!==',b,a[0])); succ.append((a[0],list(st)))
            elif op in (198,199):
                v=pop(); emit('if(%s%s null){pc=%d;continue;}'%(v,'==' if op==198 else '!=',a[0])); succ.append((a[0],list(st)))
            elif op in (167,200):
                emit('pc=%d;continue;'%a[0]); succ.append((a[0],list(st))); fall=None
            elif op==170:
                v=pop(); emit('switch(%s){'%v)
                for k,t in enumerate(a[2]): emit('case %d:pc=%d;continue;'%(a[1]+k,t)); succ.append((t,list(st)))
                emit('default:pc=%d;continue;}'%a[0]); succ.append((a[0],list(st))); fall=None
            elif op==171:
                v=pop(); emit('switch(%s){'%v)
                for k,t in a[1]: emit('case %d:pc=%d;continue;'%(k,t)); succ.append((t,list(st)))
                emit('default:pc=%d;continue;}'%a[0]); succ.append((a[0],list(st))); fall=None
            elif op in (172,173,176): emit('return %s;'%pop()); fall=None
            elif op==177: emit('return;'); fall=None
            elif op in (178,179,180,181):
                owner,name,desc=mref(a[0]); cat=cat_of(desc)
                static=op in (178,179)
                dcl,key=self.fkey(owner,name,desc,static)
                if static:
                    if dcl is not None:
                        if dcl!=c.name: guard_cls(dcl)
                        tgt=self.cref(dcl)
                    else: tgt=self.cref(owner)
                    if op==178: emit('%s=%s[%s];'%(push(cat),tgt,js(key)))
                    else: emit('%s[%s]=%s;'%(tgt,js(key),pop()))
                else:
                    if op==180: o=pop(); emit('%s=%s[%s];'%(push(cat),o,js(key)))
                    else:
                        v=pop(); o=pop(); emit('%s[%s]=%s;'%(o,js(key),v))
            elif op in (182,183,184,185):
                owner,name,desc=mref(a[0]); args,ret=parse_desc(desc)
                argv=[pop() for _ in args][::-1]
                if op==184:
                    dcl,mm=self.find_method(owner,name,desc)
                    tgt_name=dcl if dcl else owner
                    if tgt_name in self.classes and tgt_name!=c.name: guard_cls(tgt_name)
                    call='%s[%s](%s)'%(self.cref(tgt_name),js(name+desc),','.join(argv))
                    if tgt_name not in self.classes: self.rt_refs[(owner,name+desc,'s')]=True
                else:
                    recv=pop()
                    key=self.mkey(owner,name,desc)
                    if op==183:
                        call='%s.prototype[%s].call(%s%s)'%(self.cref(owner),js(key),recv,''.join(','+x for x in argv))
                        if owner not in self.classes: self.rt_refs[(owner,key,'v')]=True
                    else:
                        call='%s[%s](%s)'%(recv,js(key),','.join(argv))
                        if owner not in self.classes: self.rt_refs[(owner,key,'v')]=True
                if ret=='V': emit(call+';')
                else: emit('%s=%s;'%(push(cat_of(ret)),call))
            elif op==187:
                n=c.cname(a[0]); guard_cls(n) if n!=c.name else None
                emit('%s=%s.$new();'%(push(1),self.cref(n)))
            elif op==188:
                n=pop(); nm={4:'Int8Array',5:'Uint16Array',8:'Int8Array',9:'Int16Array',10:'Int32Array',11:'Float64Array'}[a[0]]
                emit('if(%s<0)$rt.negsize();%s=new %s(%s);'%(n,push(1),nm,n))
            elif op==189:
                n=pop(); emit('if(%s<0)$rt.negsize();%s=$rt.newObjArray(%s);'%(n,push(1),n))
            elif op==190: v=topv(); emit('%s=%s.length;'%(v,v))
            elif op==191: emit('throw %s;'%pop()); fall=None
            elif op==192: pass
            elif op==193:
                n=c.cname(a[0]); v=topv(); emit('%s=$rt.isInst(%s,%s)?1:0;'%(v,v,js(n)))
            elif op in (194,195): pop()
            elif op==197:
                dims=[pop() for _ in range(a[1])][::-1]; desc=c.cname(a[0])
                emit('%s=$rt.multiArray(%s,[%s]);'%(push(1),js(desc),','.join(dims)))
            else:
                raise Exception('unsupported opcode %d in %s.%s'%(op,c.name,m.name))
        return L,st,succ,(fall if fall is not None else None)

    def has_clinit_super(self,n):
        while n in self.classes:
            c=self.classes[n]
            if any(m.name=='<clinit>' for m in c.methods): return True
            n=c.super
        return False

def main():
    src,dst=sys.argv[1],sys.argv[2]
    classes={}
    for f in sorted(os.listdir(src)):
        if f.endswith('.class'):
            c=parse(open(os.path.join(src,f),'rb').read()); classes[c.name]=c
    comp=Compiler(classes)
    # topological order
    order=[]; done=set()
    def visit(n):
        if n in done or n not in classes: return
        done.add(n); visit(classes[n].super)
        for i in classes[n].ifaces: visit(i)
        order.append(n)
    for n in classes: visit(n)
    for k,n in enumerate(order): comp.idx[n]=k
    out=[]
    for n in order: comp.compile_class(classes[n],out)
    body='\n'.join(out)
    head='(function($rt){"use strict";const R=$rt.classes;let %s;\n'%','.join('C%d'%k for k in range(len(order)))
    tail='\n$rt.K={%s};$rt.gameClasses=%s;$rt.rtRefs=%s;$rt.rtClasses=%s;\n})'%(','.join('%s:C%d'%(json.dumps(n),k) for k,n in enumerate(order)),json.dumps(order),json.dumps([list(k) for k in comp.rt_refs]),json.dumps(list(comp.rtcls)))
    open(dst,'w').write(head+body+tail)
    print('classes',len(order),'bytes',len(head+body+tail),'rt classes',len(comp.rtcls),'rt refs',len(comp.rt_refs))
main()
