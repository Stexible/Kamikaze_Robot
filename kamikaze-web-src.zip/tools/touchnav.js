const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 }, hasTouch: true });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  const st = () => p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, bC: s.bC, items: __kr.menuItems().length }; });
  const tap = async (x, y) => { await p.touchscreen.tap(x, y); };
  await p.waitForTimeout(5000); await p.screenshot({ path: `${S}/L0.png` });
  console.log('items', JSON.stringify(await p.evaluate(() => __kr.menuItems().map(i => [i.x, i.y, i.wd, i.h]))));
  for (let i = 0; i < 40; i++) { await p.waitForTimeout(900); const s = await st(); if (s.u === 113) break; if (s.u === 118) await p.keyboard.press('Enter'); else if (s.bA !== -1 && !s.items) await p.click('#ok'); else await p.keyboard.press('Enter'); }
  const sc = (await p.evaluate(() => __kr.canvas.getBoundingClientRect())); const k = sc.height / 240;
  const items = () => p.evaluate(() => __kr.menuItems().map(i => ({ i: i.i, x: i.x, y: i.y, w: i.wd, h: i.h })));
  const tapItem = async idx => { const it = (await items()).find(q => q.i === idx); await tap(sc.left + (it.x + it.w / 2) * k, sc.top + (it.y + it.h / 2) * k); await p.waitForTimeout(2000); };
  // swipe in the main menu: scroll down by dragging up
  const swipe = async (dx, dy) => { const cx = sc.left + sc.width / 2, cy = sc.top + sc.height / 2; await p.mouse.move(cx, cy); await p.mouse.down(); for (let s = 1; s <= 10; s++) await p.mouse.move(cx + dx * s / 10, cy + dy * s / 10); await p.mouse.up(); await p.waitForTimeout(1200); };
  await swipe(0, -90); console.log('after swipe', JSON.stringify((await items()).map(q => q.i)));
  // Trophy room
  await swipe(0, 90); await swipe(0,90);
  await tapItem(6); console.log('trophy', JSON.stringify(await st())); await p.screenshot({ path: `${S}/L1.png` });
  await p.click('#nr'); await p.waitForTimeout(1200); await p.screenshot({ path: `${S}/L2.png` });
  await p.click('#back'); await p.waitForTimeout(2000);
  // About (via scrolling to it)
  await swipe(0, -140); await tapItem(12); console.log('about', JSON.stringify(await st()), await p.evaluate(()=>document.getElementById('nd').className)); await p.screenshot({ path: `${S}/L3.png` });
  await p.click('#nd'); await p.click('#nd'); await p.waitForTimeout(900); await p.screenshot({ path: `${S}/L4.png` });
  await p.click('#back'); await p.waitForTimeout(2000);
  await swipe(0, -140); await tapItem(13); console.log('exit', JSON.stringify(await st())); await p.screenshot({ path: `${S}/L5.png` });
  await p.click('#back'); await p.waitForTimeout(1500); console.log('after No', JSON.stringify(await st()));
  await b.close();
})();
