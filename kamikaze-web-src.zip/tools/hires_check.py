#!/usr/bin/env python3
"""Проверка папки с улучшенными спрайтами: python3 hires_check.py <dir>"""
import sys, os
from PIL import Image
bad = 0
for f in sorted(os.listdir(sys.argv[1])):
    if not f.endswith('.png'): continue
    key = f[:-4].split('__')[-1]; w, h = map(int, key.split('_')[0].split('x'))
    im = Image.open(os.path.join(sys.argv[1], f))
    if im.width % w or im.height % h or im.width // w != im.height // h or im.mode != 'RGBA':
        print('BAD', f, im.size, im.mode, 'expected multiple of', (w, h)); bad += 1
print('checked, bad =', bad)
