const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  await p.addInitScript(() => { window.__imgs = []; Object.defineProperty(window, '$rtHook', { value: 1 }); const iv = setInterval(() => { if (window.$rt) { clearInterval(iv); window.$rt.imgHook = (im, b, off, len) => { let h = 0; for (let i = off; i < off + len; i++) h = (h * 31 + b[i]) | 0; window.__imgs.push([im.w, im.h, len, h]); }; } }, 0); });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  const st = () => p.evaluate(() => __kr.state());
  for (let i = 0; i < 60; i++) { await p.waitForTimeout(800); const s = await st(); if (s.u === 113) break; if (s.u === 118) await p.keyboard.press('Enter'); else if (s.u === 117) await p.click('#ok'); else await p.mouse.click(420, 200); }
  const it = await p.evaluate(() => __kr.menuItems().find(q => q.i === 3)), k = await p.evaluate(() => __kr.canvas.getBoundingClientRect()), sc = k.height / 240;
  await p.mouse.click(k.left + (it.x + it.wd / 2) * sc, k.top + (it.y + it.h / 2) * sc);
  for (let i = 0; i < 25; i++) { await p.waitForTimeout(1000); const s = await st(); if (s.u === 40 || s.u === 12) break; if (await p.isVisible('#ok')) await p.click('#ok'); else await p.mouse.click(420, 200); }
  await p.waitForTimeout(3000);
  console.log(JSON.stringify(await p.evaluate(() => window.__imgs)));
  await b.close();
})();
