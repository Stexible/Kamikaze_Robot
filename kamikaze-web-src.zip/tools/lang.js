const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 844, height: 390 }, locale: process.argv[3] || 'en-US' }); const p = await ctx.newPage();
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  for (let i = 0; i < 20; i++) { await p.waitForTimeout(600); if ((await p.evaluate(() => __kr.state())).u === 118) break; }
  await p.waitForTimeout(800);
  console.log(await p.evaluate(() => { const w = __kr.D['k:[[Ljava/lang/Object;'][118]; return JSON.stringify({ sel: w[27][43], c118: __kr.D['c:[B'][118], names: __kr.E['b:[[Ljava/lang/String;'].map(x => x[0]) }); }));
  await p.screenshot({ path: `${S}/LG.png` }); await b.close();
})();
