const { chromium } = require('playwright');
// usage: shot.js <S> <w> <h> <out> : screenshot of the main menu at a given window size
(async () => {
  const [S, w, h, out] = [process.argv[2], +process.argv[3], +process.argv[4], process.argv[5]];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: w, height: h } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 400)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  const st = () => p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, items: __kr.menuItems().length }; });
  for (let i = 0; i < 40; i++) { await p.waitForTimeout(900); const s = await st(); if (s.u === 113) break; if (s.u === 118) await p.keyboard.press('Enter'); else if (s.bA !== -1 && !s.items && await p.isVisible('#ok')) await p.click('#ok'); else await p.mouse.click(420, 200); }
  await p.waitForTimeout(800); console.log(JSON.stringify(await st()), JSON.stringify(await p.evaluate(() => __kr.menuItems().map(i => [i.i, Math.round(i.x), Math.round(i.y), Math.round(i.wd), Math.round(i.h)]))));
  await p.screenshot({ path: `${S}/${out}.png` }); await b.close();
})();
