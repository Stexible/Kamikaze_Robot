const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  const st = () => p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, bC: s.bC, items: __kr.menuItems().length, sel: (__kr.menuItems()[0]||{}).w ? __kr.menuItems()[0].w[27][43] : null }; });
  for (let i = 0; i < 40; i++) { await p.waitForTimeout(900); const s = await st(); if (s.u === 113) break; if (s.u === 118) await p.keyboard.press('Enter'); else if (s.bA !== -1 && !s.items) await p.click('#ok'); else await p.keyboard.press('Enter'); }
  for (let i = 0; i < 9; i++) { await p.keyboard.press('ArrowDown'); await p.waitForTimeout(500); console.log(i, JSON.stringify(await p.evaluate(()=>__kr.menuItems().map(i=>i.i)))); if (i===7||i===8) await p.screenshot({ path: `${S}/M${i}.png` }); }
  await p.screenshot({ path: `${S}/M0.png` });
  await p.keyboard.press('Enter'); await p.waitForTimeout(2000); console.log(JSON.stringify(await st()));
  await p.screenshot({ path: `${S}/M1.png` });
  await b.close();
})();
