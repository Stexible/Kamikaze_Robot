const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 }, deviceScaleFactor: 2 });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html'+(process.argv[3]||''));
  for (let i = 0; i < 60; i++) { await p.waitForTimeout(800); const s = await p.evaluate(() => __kr.state()); if (s.u===2) await p.screenshot({path:process.argv[2]+'/t2.png'}); if (s.u === 113) break; if (s.u === 118) await p.keyboard.press('Enter'); else if (s.u === 117) await p.click('#ok'); else await p.mouse.click(420, 200); }
  await p.waitForTimeout(500); await p.screenshot({path:process.argv[2]+'/m2.png'}); await b.close();
})();
