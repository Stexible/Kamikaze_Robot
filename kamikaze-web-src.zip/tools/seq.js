// usage: node seq.js <html> <outprefix> <query> key:waitMs,key:waitMs,...   (screenshot after every step)
const { chromium } = require('playwright');
(async () => {
  const [,, file, prefix, query, steps] = process.argv;
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: +(process.env.VW||1000), height: +(process.env.VH||700) } });
  p.on('console', m => { const t = m.text(); if (!/^\[(java throw|js error)\]/.test(t) || process.env.VERBOSE) console.log('[console]', m.type(), t.slice(0, 300)); });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 600)));
  await p.goto('file://' + file + (query || ''));
  await p.waitForTimeout(3000);
  let i = 0;
  await (process.env.ELEM ? p.locator('#screen').screenshot({ path: `${prefix}${i++}.png` }) : p.screenshot({ path: `${prefix}${i++}.png` }));
  for (const s of (steps || '').split(',').filter(Boolean)) {
    const [key, ms] = s.split(':');
    if (key.startsWith('hold')) { const [, k, d] = key.split('_'); await p.keyboard.down(k); await p.waitForTimeout(+d); await p.keyboard.up(k); }
    else await p.keyboard.press(key);
    await p.waitForTimeout(+ms || 1500);
    await (process.env.ELEM ? p.locator('#screen').screenshot({ path: `${prefix}${i++}.png` }) : p.screenshot({ path: `${prefix}${i++}.png` }));
  }
  await b.close();
})();
