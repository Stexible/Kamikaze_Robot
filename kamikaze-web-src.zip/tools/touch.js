const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 844, height: 390 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  const p = await ctx.newPage();
  p.on('console', m => { if (m.type() === 'error') console.log('[console]', m.text().slice(0, 300)); });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  await p.waitForTimeout(3000);
  let n = 0;
  const log = async (l) => { const s = await p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, bC: s.bC, l: s.left, r: s.right, items: __kr.menuItems().length, vis: [...document.querySelectorAll('.gbtn.show')].map(e => e.id + ':' + e.textContent.trim()).join(',') }; }); console.log(String(n).padStart(2), l.padEnd(22), JSON.stringify(s)); await p.screenshot({ path: `${S}/T${n++}.png` }); };
  const tapItem = async (idx) => { const pt = await p.evaluate((idx) => { const its = __kr.menuItems(); const it = idx === 'first' ? its.sort((a, b) => a.y - b.y)[0] : its.find(x => x.i === idx); if (!it) return null; const r = __kr.canvas.getBoundingClientRect(), sc = r.width / $rt.screen.w; return [r.left + (it.x + it.wd / 2) * sc, r.top + (it.y + it.h / 2) * sc]; }, idx); if (!pt) { console.log('   no item', idx); return; } await p.touchscreen.tap(pt[0], pt[1]); };
  const tapBtn = async (id) => { const bb = await p.locator('#' + id).boundingBox(); await p.touchscreen.tap(bb.x + bb.width / 2, bb.y + bb.height / 2); };
  const tapCanvas = async () => { const r = await p.locator('#screen').boundingBox(); await p.touchscreen.tap(r.x + r.width / 2, r.y + r.height / 3); };
  await log('language menu');
  await tapItem(1); await p.waitForTimeout(2000); await log('tapped item 1 (Fr)');
  await tapBtn('ok'); await p.waitForTimeout(3500); await log('Yes (sound)');
  await tapCanvas(); await p.waitForTimeout(2500); await log('tap intro/skip');
  await tapCanvas(); await p.waitForTimeout(2500); await log('tap title');
  await tapItem('first'); await p.waitForTimeout(2500); await log('tap Quick Game');
  await tapBtn('back'); await p.waitForTimeout(2500); await log('No (tutorial)');
  for (let k = 0; k < 8; k++) {
    const s = await p.evaluate(() => ({ u: __kr.state().u, items: __kr.menuItems().length, ok: document.getElementById('ok').classList.contains('show') }));
    if (s.u === 40 || s.u === 12) break;
    if (s.items) await tapItem('first'); else if (s.ok) await tapBtn('ok'); else await tapCanvas();
    await p.waitForTimeout(2500); await log('advance');
  }
  await p.waitForTimeout(2500); await log('race running?');
  const r = await p.locator('#screen').boundingBox();
  await p.mouse.move(r.x + 200, r.y + 150); await p.mouse.down(); await p.waitForTimeout(900); await p.mouse.up(); await p.waitForTimeout(800); await log('after hold anywhere');
  await tapBtn('pause'); await p.waitForTimeout(1500); await log('pause tapped');
  await tapItem('first'); await p.waitForTimeout(2000); await log('tap Resume');
  await b.close();
})();
