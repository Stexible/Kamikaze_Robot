const { chromium } = require('playwright');
// usage: nav.js <S> <menuIndex> [tag]  -> opens main-menu item, prints state, screenshots
(async () => {
  const S = process.argv[2], idx = +process.argv[3], tag = process.argv[4] || 'N';
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  const st = () => p.evaluate(() => { const s = __kr.state(); return { u: s.u, bA: s.bA, bC: s.bC, items: __kr.menuItems().length }; });
  for (let i = 0; i < 40; i++) {
    await p.waitForTimeout(900); const s = await st();
    if (s.u === 113) break;
    if (s.u === 118) await p.keyboard.press('Enter');
    else if (s.bA !== -1 && s.items === 0) await p.click('#ok'); else await p.keyboard.press('Enter');
  }
  const it = await p.evaluate(() => __kr.menuItems().map(i => [i.x, i.y, i.wd, i.h])); console.log(JSON.stringify(it));
  const k = await p.evaluate(() => __kr.canvas.getBoundingClientRect()), sc = k.height / 240;
  // scroll menu if needed
  const T = it[idx]; await p.mouse.click(k.left + (T[0] + T[2] / 2) * sc, k.top + (T[1] + T[3] / 2) * sc);
  await p.waitForTimeout(2500); if ((await st()).u===123) { await p.click('#back'); await p.waitForTimeout(2500);} for (let i=0;i<14 && [30,61,62].includes((await st()).u);i++){ await p.click('#ok'); await p.waitForTimeout(1500);} console.log(JSON.stringify(await st()));
  await p.screenshot({ path: `${S}/${tag}0.png` });
  global.p = p; global.S = S; global.tag = tag;
  const keys = (process.argv[5] || '').split(',').filter(Boolean);
  let n = 1;
  for (const key of keys) { await p.keyboard.down(key); await p.waitForTimeout(350); await p.keyboard.up(key); await p.waitForTimeout(900); console.log(key, JSON.stringify(await st())); await p.screenshot({ path: `${S}/${tag}${n++}.png` }); }
  await b.close();
})();
