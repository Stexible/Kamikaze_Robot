const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 844, height: 390 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  p.on('console', m => { if (m.type()==='error'||m.type()==='warning') console.log('[c]', m.text().slice(0,200)); });
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  for (let i = 0; i < 40; i++) {
    await p.waitForTimeout(1000); const s = await p.evaluate(() => __kr.state());
    if (s.game) break;
    if (s.u === 118) await p.keyboard.press('Enter'); else if (s.bA !== -1 && !(await p.evaluate(()=>__kr.menuItems().length))) await p.click('#ok');
    else if (s.u === 113 || (await p.evaluate(()=>__kr.menuItems().length))) { const it = await p.evaluate(() => __kr.menuItems()[0]); const k = await p.evaluate(() => __kr.canvas.getBoundingClientRect()); const sc=k.height/240; await p.mouse.click(k.left+(it.x+it.wd/2)*sc, k.top+(it.y+it.h/2)*sc); }
    else await p.keyboard.press('Enter');
  }
  console.log(JSON.stringify(await p.evaluate(() => __kr.state())));
  for (let i=0;i<30;i++){ const s=await p.evaluate(()=>__kr.state()); if (s.game) break; if (s.u===43||s.u===81||s.u===82||s.bA!==-1) { await p.keyboard.press('Enter'); } await p.waitForTimeout(700);} console.log(JSON.stringify(await p.evaluate(() => __kr.state())));
  const probe = () => p.evaluate(() => ({ u: __kr.D['u:I'], c: __kr.D['c:I'], keys: [...(window.__downs||[])] }));
  console.log('idle', JSON.stringify(await probe()));
  await p.keyboard.down('Space'); await p.waitForTimeout(400); console.log('space', JSON.stringify(await probe()));
  await p.keyboard.up('Space'); await p.waitForTimeout(300); console.log('up', JSON.stringify(await probe()));
  await p.mouse.move(400,200); await p.mouse.down(); await p.waitForTimeout(400); console.log('mouse', JSON.stringify(await probe())); await p.mouse.up();
  await p.screenshot({ path: `${process.argv[2]}/H.png` });
  await b.close();
})();
