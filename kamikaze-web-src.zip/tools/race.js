const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] }); const p = await b.newPage({ viewport: { width: 960, height: 540 } });
  p.on('console', m => { const t = m.text(); if (m.type() === 'error' || /unexpected|MISSING/.test(t)) console.log('[console]', m.type(), t.slice(0, 400)); });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 600)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  await p.waitForTimeout(3000);
  // language, sounds YES (q), logo, intro skip, ...
  const seq = [['Enter',2000],['q',3000],['Enter',2500],['q',3000],['e',2500],['Enter',2500]];
  for (const [k, ms] of seq) { await p.keyboard.press(k); await p.waitForTimeout(ms); }
  await p.screenshot({ path: `${S}/Q0.png` });
  const audio = await p.evaluate(() => ({ state: $rt.audio.ctx && $rt.audio.ctx.state, active: $rt.audio.active.size }));
  console.log('audio', JSON.stringify(audio));
  const mids = await p.evaluate(() => Object.keys($rt.res).map(k => k)); 
  const r = await p.evaluate(() => { const out = []; for (const k of Object.keys($rt.res)) { const u = $rt.res[k]; /* scan entries for MThd */ const b = new Uint8Array(u.buffer, u.byteOffset, u.length); for (let i = 0; i < b.length - 4; i++) if (b[i]===0x4d&&b[i+1]===0x54&&b[i+2]===0x68&&b[i+3]===0x64) { try { const s = $rt.audio.parse(b.subarray(i)); out.push([k, i, s.events.length, +s.dur.toFixed(1)]); } catch (e) { out.push([k, i, 'ERR ' + e.message]); } } } return out; });
  console.log('midi', JSON.stringify(r));
  await p.keyboard.press('e'); await p.waitForTimeout(2500);
  await p.keyboard.press('Enter'); await p.waitForTimeout(2500);
  let n = 1;
  const shot = async () => p.screenshot({ path: `${S}/Q${n++}.png` });
  await p.keyboard.press('q'); await p.waitForTimeout(2500); await shot();
  await p.keyboard.press('Enter'); await p.waitForTimeout(3500); await shot();
  for (let k = 0; k < 6; k++) { await p.keyboard.down('Enter'); await p.waitForTimeout(900); await p.keyboard.up('Enter'); await p.waitForTimeout(1600); await shot(); }
  const perf = await p.evaluate(() => ({ ...$rt.perf, avg: $rt.perf.ms / $rt.perf.n })); console.log('perf', JSON.stringify(perf));
  await b.close();
})();
