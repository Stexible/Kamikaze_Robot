const { chromium } = require('playwright');
(async () => {
  const S = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 960, height: 540 } });
  p.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 300)));
  await p.goto('file:///home/claude/kamikaze-web/dist/kamikaze.html');
  await p.waitForTimeout(3000);
  const st = async (label) => console.log(label.padEnd(26), JSON.stringify(await p.evaluate(() => __kr.state())));
  await st('lang menu');
  for (const [k, ms, l] of [['Enter',2000,'sound prompt'],['e',2500,'logo'],['Enter',2000,'intro'],['q',3000,'title'],['Enter',2500,'main menu'],['Enter',2500,'tutorial prompt'],['e',2500,'after No'],['q',2500,'after OK'],['Enter',3500,'after start']]) { await p.keyboard.press(k); await p.waitForTimeout(ms); await st(l); }
  await p.keyboard.down('Enter'); await p.waitForTimeout(800); await p.keyboard.up('Enter'); await p.waitForTimeout(1000);
  await st('race (after hold)');
  await p.keyboard.press('e'); await p.waitForTimeout(1500); await st('after right softkey'); await p.screenshot({ path: `${S}/pause.png` });
  await b.close();
})();
