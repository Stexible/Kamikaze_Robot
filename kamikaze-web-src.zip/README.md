# Kamikaze Robots — web port

Faithful browser port of the original J2ME game (Digital Chocolate, 2007): the original bytecode is
translated to JavaScript, and a small MIDP/Nokia-UI runtime replaces the phone APIs.

* `tools/jvm2js.py`  – JVM bytecode -> JS translator (7 classes, ints/longs/refs/arrays, exceptions, switches)
* `src/rt.js`        – runtime: java.lang/io/util subset, MIDP lcdui on <canvas>, sync PNG decoder, RMS on localStorage
* `src/audio.js`     – Standard-MIDI player on WebAudio (4 tracks)
* `src/boot.js`      – adaptive resolution (landscape: 240px high, portrait: 240px wide), keyboard, touch, pause, fullscreen
* `tools/build.py`   – packs everything + the game's resources into one self-contained `dist/kamikaze.html`

Build (you need the original JAR, unzipped to a folder):

    unzip game.jar -d jar_dir
    python3 tools/jvm2js.py jar_dir dist/game.js
    python3 tools/build.py jar_dir          # -> dist/kamikaze.html

Controls: arrows/WASD = menu, Space/Enter/5 = hold to spin, Q/E (or F1/F2, Esc) = left/right soft key.
Touch: on-screen d-pad + HOLD button; tap the lower-left/right screen corner for the soft keys.
URL options: `?debug` (log caught Java exceptions), `?touch=1` (force touch UI), `?w=427&h=240` (force resolution).

Test helpers (need Playwright): `tools/seq.js`, `tools/soak.js`, `tools/race.js`, `tools/rotate.js`.

## Russian + fonts
- `python3 tools/mk_ru.py <extracted_jar_dir>` writes `l7_0..l7_5` (Russian tables; the game discovers languages by probing `l<N>_0`) and patches the English hint strings that mentioned phone keys. Run it before `tools/build.py`.
- The three bitmap fonts of the game are replaced at load time by system fonts (see `boot.js`, `?pixelfont` in the URL keeps the originals). The canvas backing store is up to 4x denser than the logical 240px screen, so text is smooth while sprites stay crisp.

## Race music
`python3 tools/mk_music.py <jar_dir> [--export dir]` generates nine MIDI tracks (`m0..m8`, one per tournament checkpoint; Quick Game picks them in rotation). `boot.js` swaps them in for the original race song (`?origmusic` in the URL restores it).
## UI
Exit is an item of the main menu; trophy/stage/text screens have native arrows + swipe gestures.

## Custom race music (current)
Put `.mid` files into the jar dir as `u0`, `u1`, ... (see `res_music/`); each race then picks at random between the original song and these (`?origmusic` = original only). The generated set from `tools/mk_music.py` (m0..m8) is no longer used by default.

## Hi-res sprites
`res_hires/<WxH_hash>.png` (or `NNN__<WxH_hash>.png`) replaces the game image with that key (hash of its PNG bytes, see `im.k` in rt.js);
it is drawn scaled into the original WxH box. Currently: the title logo (user's artwork). `?nohires` disables. `tools/hires_check.py <dir>` validates files.
`tools/dump.js` dumps all game sprites by key.
