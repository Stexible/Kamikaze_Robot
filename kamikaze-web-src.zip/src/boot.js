(function () {
'use strict';
const params = new URLSearchParams(location.search);
const canvas = document.getElementById('screen');
const err = document.getElementById('err');
window.addEventListener('error', e => { err.textContent += (e.message || e) + '\n'; });

// ---- resources
const res = {};
$rt.hires = {}; if (!/[?&]nohires/.test(location.search)) for (const k in (window.KR_HIRES || {})) { const i = new Image(); i.src = 'data:image/png;base64,' + KR_HIRES[k]; $rt.hires[k] = i; }
for (const k in KR_RES) { const s = atob(KR_RES[k]), a = new Int8Array(s.length); for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); res[k] = a; }

// ---- logical resolution: the game's UI is drawn for ~240px; keep that scale and adapt the other side to the window
function pickSize() {
  const fw = +params.get('w'), fh = +params.get('h'); if (fw && fh) return [fw, fh];
  const asp = innerWidth / Math.max(1, innerHeight);
  const even = v => Math.round(v / 2) * 2;
  if (asp >= 1) return [Math.min(560, Math.max(320, even(240 * asp))), 240];
  return [240, Math.min(520, Math.max(320, even(240 / asp)))];
}
[$rt.screen.w, $rt.screen.h] = pickSize();
$game($rt);
const E = $rt.K.e, D = $rt.K.DCBolt;
const WIDGET_DRAW = 'a([Ljava/lang/Object;Ljavax/microedition/lcdui/Graphics;II)V';

// native soft keys: the game stops drawing its own labels, we show real buttons instead
E['q(Ljavax/microedition/lcdui/Graphics;)V'] = function () {};
// remember every menu widget painted in the last frame (for tap hit-testing)
let widgets = [];
{
  const orig = D[WIDGET_DRAW];
  D[WIDGET_DRAW] = function (w, g, x, y) {
    const f = w.$fit;
    if (!f) { widgets.push([w, x, y]); return orig.call(this, w, g, x, y); }
    const W = $rt.screen.w, H = $rt.screen.h, tx = Math.round((W - f.vw * f.s) / 2) + x, ty = y;
    widgets.push([w, 0, 0, f.s, tx, ty]);
    g.xf = [tx, ty, f.s]; g.clip = [0, 0, Math.ceil(W / f.s), Math.ceil(H / f.s)]; g.dirty = true;
    try { return orig.call(this, w, g, 0, 0); } finally { g.xf = null; g.clip = [0, 0, W, H]; g.dirty = true; }
  };
  $rt.onFrame = () => { widgets = []; chipRows = []; chipArrows = {}; };
}
// bitmap fonts -> system fonts (smooth, and covers any alphabet, e.g. Cyrillic)
{
  const FD = 'a([Ljava/lang/Object;Ljavax/microedition/lcdui/Image;Ljava/io/DataInputStream;Ljavax/microedition/lcdui/Font;II)V', origF = D[FD];
  const Font = $rt.classes['javax/microedition/lcdui/Font'];
  D[FD] = function (o, img, dis, font, c1, c2) {
    const r = origF.call(this, o, img, dis, font, c1, c2);
    if (img && !params.has('pixelfont')) {
      // the three bitmap fonts of the game, keyed by (ascent,descent): [px, fill, outline, bold]
      const SUB = { '7,10': [13, 0xfefefe, 0x204757, 1], '6,9': [12, 0x22437f, -1, 1], '10,12': [17, 0xffffff, 0x67003f, 1] };
      const s = SUB[o[7][0] + ',' + o[7][1]];
      if (s) {
        const f = Font.$new(), ol = s[2] !== -1, hg = o[7][0] + o[7][1] - (ol ? 2 : 0);
        f.px = s[0]; f.hgt = hg; f.css = (s[3] ? 'bold ' : '') + s[0] + 'px "Trebuchet MS","Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
        o[9] = null; o[8] = f; o[6][0] = s[1]; o[6][1] = s[2]; o[7][2] = ol ? 1 : 0;
      }
    }
    return r;
  };
}
// language list changed (Russian inserted as #2): map a previously saved language index once
{
  let migrate = false; try { migrate = !localStorage.getItem('kr_lang_v2'); localStorage.setItem('kr_lang_v2', '1'); } catch (e) {}
  const JK = 'J(I)V', origJ = E[JK];
  E[JK] = function (n) {
    const f = D['f:[I'];
    if (migrate && f && n !== 0 && n === f[2]) { migrate = false; n = f[2] = (n === 7 ? 1 : n + 1); }   // old: ... pt 5, el 6, ru 7 -> new order en ru fr it de es pt el
    return origJ.call(this, n);
  };
  const stop = setInterval(() => { const u = D['u:I']; if (u === 118 || u === 2 || u === 113) { migrate = false; clearInterval(stop); } }, 200);
}
// race music: each race plays either the original song or one of the extra tracks (resources u0, u1, ...) at random
{
  const RB = 'a(I)[B', origR = E[RB], b64 = s => { const bin = atob(s), a = new Int8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return a; };
  const extra = []; for (let i = 0; i < 20; i++) { const r = window.KR_RES['/u' + i]; if (r) extra.push(r); }
  E[RB] = function (n) {
    const r = origR.apply(this, arguments);
    if (n === 131072 && extra.length && !params.has('origmusic')) {
      const k = (Math.random() * (extra.length + 1)) | 0;            // 0 = the original song
      window.__track = k; if (k > 0) return b64(extra[k - 1]);
    }
    return r;
  };
}
// main menu: always show every item. The list is laid out in a 240px-wide virtual space tall enough for all items,
// then drawn scaled (smooth text) and centred; hit-testing maps through the same transform.
{
  const LAY = 'b([Ljava/lang/Object;II)V', origL = D[LAY];
  D[LAY] = function (w, a, b) {
    const act = w[21];
    if (!(act && act[12] === 116 && act[11] === 102)) return origL.call(this, w, a, b);
    const VW = 240; origL.call(this, w, VW, b);
    const p = w[27], view = p[41], h28 = p[28]; let s = 1;
    if (p[2] > view && view > 0) { origL.call(this, w, VW, b + (p[2] - view) + 2); s = view / p[41]; p[28] = h28; }   // p[28] also positions the logo: keep the real height
    w.$fit = { s, vw: VW };
    return;
  };
}
// chip-upgrade screen: remember where the four property rows were drawn
let chipRows = [], chipArrows = {};
{
  const BD = 'b([Ljava/lang/Object;Ljavax/microedition/lcdui/Graphics;II)V', origB = D[BD];
  D[BD] = function (spr, g, x, y) {
    if (D['u:I'] === 31) { const G = D['g:[[Ljava/lang/Object;']; if (G && (spr === G[9] || spr === G[10])) chipRows.push([x, y, D['h([Ljava/lang/Object;)I'](spr), D['i([Ljava/lang/Object;)I'](spr)]); }
    if (D['u:I'] === 31) { const G = D['g:[[Ljava/lang/Object;']; if (G && (spr === G[1] || spr === G[2])) chipArrows[spr === G[1] ? 'l' : 'r'] = [x, y, D['h([Ljava/lang/Object;)I'](spr), D['i([Ljava/lang/Object;)I'](spr)]; }
    return origB.call(this, spr, g, x, y);
  };
}
$rt.start(canvas, res, KR_PROPS);

// ---- screen fitting
function fit() {
  const dpr = window.devicePixelRatio || 1, W = innerWidth, H = innerHeight, w = $rt.screen.w, h = $rt.screen.h;
  let s = Math.min(W / w, H / h);
  if (s >= 1) { const si = Math.max(1 / dpr, Math.floor(s * dpr) / dpr); if (s / si < 1.25) s = si; }
  canvas.style.width = Math.floor(w * s) + 'px'; canvas.style.height = Math.floor(h * s) + 'px';
  // denser backing store => smooth (non-pixel) text; sprites stay crisp (nearest-neighbour)
  const k = Math.max(1, Math.min(4, Math.ceil(s * dpr - 0.01), Math.floor(Math.sqrt(2.6e6 / (w * h)))));
  if (k !== $rt.screen.k) $rt.setScreen(w, h, k);
  canvas.classList.toggle('smooth', k > 1);
}
let rz = null;
addEventListener('resize', () => {
  fit(); clearTimeout(rz);
  rz = setTimeout(() => { const [w, h] = pickSize(); if (w !== $rt.screen.w || h !== $rt.screen.h) { $rt.setScreen(w, h); fit(); } }, 200);
});
fit();

// ---- game state
function gstate() {
  const u = D['u:I'];
  return { u, game: u === 12 || u === 40 || u === 43, bA: E['bA:I'], bC: E['bC:I'], left: E['h:Ljava/lang/String;'], right: E['i:Ljava/lang/String;'] };
}
// visible item rectangles (logical px) of the widgets painted last frame, topmost first
function menuItems() {
  const out = [];
  for (let k = widgets.length - 1; k >= 0; k--) {
    const [w, ox0, oy0, sc, tx, ty] = widgets[k];
    try {
      const f = w[0], p = w[27], r = w[16]; if (!p || !r) continue;
      let ox = ox0, oy = oy0;
      if (f[1]) { ox += 4; oy += 4; }
      if ((p[42] & 2) !== 0 && p[2] < p[41]) oy += (p[41] - p[2]) >> 1;
      const vy = oy + p[39];
      for (let i = 0; i < p[29]; i++) {
        const kd = w[15]; if (kd && (kd[i] === -1 || kd[i] === 1)) continue;   // -1 = unused slot, 1 = static text line
        const full = p[40] > 0 && r[i * 4 + 2] > 0;                                  // hit area = the whole row, not only the text
        const x = ox + p[38] + (full ? 0 : r[i * 4]), y = vy + r[i * 4 + 1] - p[0], wd = full ? p[40] : r[i * 4 + 2], h = r[i * 4 + 3];
        if (wd <= 0 || h <= 0) continue;
        if (p[25] === 0 ? (y < vy || y + h > vy + p[41]) : (y + h < vy || y >= vy + p[41])) continue;
        out.push(sc ? { w, i, x: tx + x * sc, y: ty + y * sc, wd: wd * sc, h: h * sc } : { w, i, x, y, wd, h });
      }
    } catch (e) { /* widget without list geometry */ }
  }
  return out;
}

// ---- keys
const down = new Set();
function press(c) { if (down.has(c)) return; down.add(c); $rt.key('down', c); }
function release(c) { if (!down.has(c)) return; down.delete(c); $rt.key('up', c); }
function releaseAll() { for (const c of [...down]) release(c); }
function tapKey(c) { $rt.key('down', c); $rt.key('up', c); }
const keymap = { ArrowUp: -1, ArrowDown: -2, ArrowLeft: -3, ArrowRight: -4, Enter: -5, ' ': -5, w: -1, s: -2, a: -3, d: -4, q: -6, e: -7, F1: -6, F2: -7, Escape: -7, Backspace: -7, p: -7, '*': 42, '#': 35 };
function kcode(e) { if (e.key in keymap) return keymap[e.key]; const k = e.key.length === 1 ? e.key.toLowerCase() : e.key; if (k in keymap) return keymap[k]; if (/^[0-9]$/.test(e.key)) return e.key.charCodeAt(0); return null; }
addEventListener('keydown', e => { if (e.ctrlKey || e.metaKey || e.altKey) return; const c = kcode(e); if (c === null) return; e.preventDefault(); if (!e.repeat) press(c); });
addEventListener('keyup', e => { const c = kcode(e); if (c === null) return; e.preventDefault(); release(c); });
addEventListener('blur', releaseAll);

// ---- native buttons (Back = right soft key, OK/Yes/Select = left soft key, Pause in the race)
const $minus = document.getElementById('minus'), $plus = document.getElementById('plus');
for (const [el, code] of [[$minus, -3], [$plus, -4]]) {
  el.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); el.classList.add('on'); press(code); });
  const off = () => { if (el.classList.contains('on')) { el.classList.remove('on'); release(code); } };
  el.addEventListener('pointerup', off); el.addEventListener('pointercancel', off); el.addEventListener('pointerleave', off);
}
const $back = document.getElementById('back'), $ok = document.getElementById('ok'), $pause = document.getElementById('pause');
function bindButton(el, code) {
  el.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); el.classList.add('on'); tapKey(code); });
  const off = () => el.classList.remove('on');
  el.addEventListener('pointerup', off); el.addEventListener('pointercancel', off); el.addEventListener('pointerleave', off);
}
bindButton($back, -7); bindButton($pause, -7); $ok.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); $ok.classList.add('on'); if (D['u:I'] === 31) { press(-5); setTimeout(() => release(-5), 160); } else tapKey(-6); });
$ok.addEventListener('pointerup', () => $ok.classList.remove('on')); $ok.addEventListener('pointerleave', () => $ok.classList.remove('on'));

// held-key pulse (screens that poll the key mask per frame need the key held for a moment)
let pq = Promise.resolve();
let pqLen = 0;
function pulse(c) { pqLen++; pq = pq.then(() => new Promise(r => { press(c); setTimeout(() => { release(c); setTimeout(() => { pqLen--; r(); }, 30); }, 50); })); }
const navBtn = { nu: -1, nd: -2, nl: -3, nr: -4 }, $nav = {};
for (const id in navBtn) {
  const el = $nav[id] = document.getElementById(id); let t1 = null, t2 = null, held = false;
  const off = () => { el.classList.remove('on'); clearTimeout(t1); clearInterval(t2); t1 = t2 = null; if (held) { held = false; release(navBtn[id]); } };
  el.addEventListener('pointerdown', e => {
    e.preventDefault(); e.stopPropagation(); el.classList.add('on');
    if ((id === 'nu' || id === 'nd') && gstate().u !== 9) { held = true; press(navBtn[id]); return; }   // text pages: hold the key = keep scrolling
    pulse(navBtn[id]);                                                                                  // chart / trophies: one step per press, auto-repeat while held
    t1 = setTimeout(() => { t2 = setInterval(() => { if (pqLen < 2) pulse(navBtn[id]); }, 70); }, 320);
  });
  el.addEventListener('pointerup', off); el.addEventListener('pointercancel', off); el.addEventListener('pointerleave', off);
}
// mouse wheel = scroll lists / text / stage chart
let wheelAcc = 0;
document.getElementById('stage').addEventListener('wheel', e => {
  const s = gstate(); if (s.game || s.u === 31) return; e.preventDefault();
  wheelAcc += e.deltaY; const step = 40;
  while (wheelAcc >= step) { wheelAcc -= step; pulse(-2); } while (wheelAcc <= -step) { wheelAcc += step; pulse(-1); }
}, { passive: false });
const overflowing = () => widgets.some(([w]) => { const q = w[27]; return q && q[2] > q[41] && q[41] > 0; });
const frame = document.getElementById('frame');
let sig = '';
let skipTxt = null;
function skipText() { if (skipTxt === null) { try { skipTxt = E['c(I)Ljava/lang/String;'](131127); } catch (e) { skipTxt = ''; } } return skipTxt; }
function syncUI() {
  const s = gstate(), items = s.game ? [] : menuItems();
  const showBack = !s.game && s.bC !== -1 && s.u !== 113, showOk = !s.game && s.u !== 9 && s.bA !== -1 && items.length === 0 && !(s.bC === -1 && s.left && s.left === skipText()), showPause = s.game && s.bC !== -1;
  const chip = s.u === 31 && chipRows.length >= 4;
  const stack = showBack && showOk;
  const left6 = chip ? D['e:[I'][6] : 0;
  const vnav = !s.game && !chip && ((s.u === 9) || (items.length === 0 && overflowing())), hnav = s.u === 124;
  const nsig = [vnav, hnav, left6, showBack, s.right, showOk, s.left, showPause, chip, stack].join('|');
  if (nsig !== sig) {
    sig = nsig;
    $back.textContent = s.right || 'Back'; $back.classList.toggle('show', showBack);
    $ok.textContent = s.left || 'OK'; $ok.classList.toggle('show', showOk);
    $pause.classList.toggle('show', showPause);
    frame.classList.toggle('stack', stack);
    frame.classList.toggle('chip', chip);
    $nav.nu.classList.toggle('show', vnav); $nav.nd.classList.toggle('show', vnav); $nav.nl.classList.toggle('show', hnav); $nav.nr.classList.toggle('show', hnav);
    $ok.classList.toggle('dim', chip && left6 > 0);   // the game only accepts OK once every chip is placed
    for (const el of [$minus, $plus]) el.classList.toggle('show', chip);
    $ok.textContent = chip ? 'OK' : ($ok.textContent); $ok.classList.toggle('show', showOk || chip);
    document.getElementById('fs').classList.toggle('hide', s.game);
  }
  requestAnimationFrame(syncUI);
}
requestAnimationFrame(syncUI);

// ---- pointer input on the whole stage
const stage = document.getElementById('stage');
const holders = new Set();
function toLogical(e) {
  const r = canvas.getBoundingClientRect();
  if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) return null;
  return [(e.clientX - r.left) / r.width * $rt.screen.w, (e.clientY - r.top) / r.height * $rt.screen.h];
}
function activate(it) {
  const p = it.w[27];
  for (let g = 0; g < 40 && p[43] !== it.i; g++) {
    const before = p[43];
    tapKey(it.i > before ? -2 : -1);
    if (p[43] === before) break;
  }
  if (p[43] === it.i) tapKey(-5);
}
let stepping = false;
function stepRow(r) {   // the chip screen polls held keys per frame with a repeat delay: hold each step briefly
  if (stepping) return; stepping = true;
  const ee = D['e:[I']; let n = 0;
  const go = () => {
    if (ee[4] === r || n++ > 8) { stepping = false; return; }
    const c = r > ee[4] ? -2 : -1, b = ee[4];
    press(c); setTimeout(() => { release(c); setTimeout(go, 90); }, 90);
  };
  go();
}
let gest = null; const arrowHold = new Map();
function tapAt(pt, s) {
  if (s.u === 31 && chipRows.length >= 4) {
    const r = chipRows.findIndex(([x, y, w, h]) => pt[0] >= x && pt[0] < x + w && pt[1] >= y && pt[1] < y + h);
    if (r >= 0) { stepRow(r); }
    return;
  }
  const items = menuItems();
  const hit = items.find(it => pt[0] >= it.x && pt[0] < it.x + it.wd && pt[1] >= it.y && pt[1] < it.y + it.h);
  if (hit) { activate(hit); return; }
  if (items.length) return;                                       // tapped empty space of a list
  if (s.u === 124) return;                                        // trophies: native arrows + swipe only
  if (s.u === 9) { tapKey(-6); return; }                          // stage chart: a tap anywhere = OK
  if (s.bA !== -1 && s.bC === -1) tapKey(-6);                     // single-button screens (OK / Skip): tap anywhere
  else if (s.bA === -1 && s.bC === -1) tapKey(-5);                // "press any key" screens
}
stage.addEventListener('pointerdown', e => {
  if (e.button > 0) return;
  e.preventDefault(); try { stage.setPointerCapture(e.pointerId); } catch (x) {}
  const s = gstate();
  if (s.game) { holders.add(e.pointerId); press(-5); return; }   // race: hold anywhere = key 5
  const pt = toLogical(e); if (!pt) return;
  if (s.u === 31) {                                                  // sprite arrows beside the selected bar: hold = keep adding / removing
    for (const [side, code] of [['l', -3], ['r', -4]]) {
      const a = chipArrows[side]; if (!a) continue;
      const cx = a[0] + a[2] / 2, cy = a[1], hw = Math.max(a[2] / 2, 8) + 8, hh = Math.max(a[3] / 2, 8) + 10;
      if (Math.abs(pt[0] - cx) <= hw && Math.abs(pt[1] - cy) <= hh) { arrowHold.set(e.pointerId, code); press(code); return; }
    }
  }
  gest = { id: e.pointerId, x: e.clientX, y: e.clientY, pt, s, moved: false, axis: null, sent: 0 };
});
stage.addEventListener('pointermove', e => {
  const g = gest; if (!g || g.id !== e.pointerId) return;
  const k = canvas.getBoundingClientRect().height / $rt.screen.h;           // css px per logical px
  const dx = (e.clientX - g.x) / k, dy = (e.clientY - g.y) / k;
  if (!g.axis) { if (Math.hypot(dx, dy) < 6) return; g.axis = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y'; g.moved = true; }
  if (g.s.u === 31) return;
  const step = g.axis === 'y' ? 16 : 36, d = g.axis === 'y' ? dy : dx;
  const n = Math.trunc(-d / step);                                          // finger up/left = move forward
  while (g.sent < n) { g.sent++; pulse(g.axis === 'y' ? -2 : -4); }
  while (g.sent > n) { g.sent--; pulse(g.axis === 'y' ? -1 : -3); }
});
const endGest = e => { if (arrowHold.has(e.pointerId)) { release(arrowHold.get(e.pointerId)); arrowHold.delete(e.pointerId); return; }
  const g = gest; if (!g || g.id !== e.pointerId) return; gest = null; if (!g.moved && e.type === 'pointerup') tapAt(g.pt, g.s); };
stage.addEventListener('pointerup', endGest); stage.addEventListener('pointercancel', endGest);
const endPtr = e => { if (holders.delete(e.pointerId) && holders.size === 0) release(-5); };
stage.addEventListener('pointerup', endPtr); stage.addEventListener('pointercancel', endPtr);
stage.addEventListener('contextmenu', e => e.preventDefault());

// ---- fullscreen / pause
const fsb = document.getElementById('fs');
fsb.addEventListener('pointerdown', e => e.stopPropagation());
fsb.addEventListener('click', async () => {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else { await document.documentElement.requestFullscreen(); if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => {}); }
  } catch (e) {}
});
document.addEventListener('visibilitychange', () => {
  const m = $rt.midlet; if (!m) return;
  if (document.hidden) { releaseAll(); try { m['pauseApp()V'](); } catch (e) {} if ($rt.audio.ctx) $rt.audio.ctx.suspend(); }
  else { try { m['startApp()V'](); } catch (e) {} if ($rt.audio.ctx) $rt.audio.ctx.resume(); }
});
window.__kr = { canvas, fit, press, release, state: gstate, menuItems, tapKey, widgets: () => widgets, rows: () => chipRows, arrows: () => chipArrows, D, E };
})();
