/* Minimal JVM/MIDP runtime for the translated Kamikaze Robots bytecode. */
(function (global) {
'use strict';
const classes = {};
const $rt = { classes, screen: { w: 320, h: 240 }, res: {}, props: {}, canvasEl: null };
global.$rt = $rt;

// ---------------------------------------------------------------- class system
class JObject {}
JObject.$name = 'java/lang/Object'; JObject.$super = null; JObject.$ifaces = [];
JObject.$names = new Set(['java/lang/Object']);
classes['java/lang/Object'] = JObject;

function finish(K, name, sup, ifaces) {
  K.$name = name; K.$super = sup; K.$ifaces = ifaces || [];
  K.$names = new Set(sup ? sup.$names : []);
  K.$names.add(name);
  for (const i of K.$ifaces) { K.$names.add(i); const ic = classes[i]; if (ic && ic.$names) for (const n of ic.$names) K.$names.add(n); }
  K.$ok = false; K.$hasClinit = false; K.$fields = [];
  K.$init = function () {
    if (K.$ok) return; K.$ok = true;
    if (sup && sup.$init && !sup.$ok) sup.$init();
    if (K.$clinit) K.$clinit();
  };
  K.$new = function () {
    const o = new K();
    if (!K.$all) { K.$all = []; for (let k = K; k; k = k.$super) if (k.$fields) K.$all.push(...k.$fields); }
    const a = K.$all; for (let i = 0; i < a.length; i++) o[a[i][0]] = a[i][1];
    return o;
  };
  classes[name] = K;
  return K;
}
function defClass(name, sup, ifaces) {
  const S = sup || JObject;
  const K = class extends S {};
  return finish(K, name, S, ifaces);
}
$rt.defClass = defClass;
JObject.$init = function () {}; JObject.$ok = true;
JObject.$new = function () { return new JObject(); };

// define an rt class from a spec { sup, ifs, i: {instance methods}, s: {static methods}, f: {static fields} }
function def(name, spec) {
  const sup = spec.sup ? classes[spec.sup] : JObject;
  if (!sup) throw new Error('rt: missing super ' + spec.sup + ' for ' + name);
  const K = defClass(name, sup, spec.ifs || []);
  K.$ok = true;
  if (spec.fields) K.$fields = spec.fields;
  for (const k in (spec.i || {})) K.prototype[k] = spec.i[k];
  for (const k in (spec.s || {})) K[k] = spec.s[k];
  return K;
}

function isInst(o, name) {
  if (o == null) return false;
  if (typeof o === 'string') return name === 'java/lang/String' || name === 'java/lang/Object' || name === 'java/lang/Comparable';
  if (ArrayBuffer.isView(o) || Array.isArray(o)) return name === 'java/lang/Object' || name[0] === '[';
  const K = o.constructor; return !!(K.$names && K.$names.has(name));
}
$rt.isInst = isInst;

// ---------------------------------------------------------------- exceptions
function exc(name, sup) {
  def(name, { sup, i: {
    '<init>()V'() { this.msg = null; },
    '<init>(Ljava/lang/String;)V'(m) { this.msg = m; },
    'getMessage()Ljava/lang/String;'() { return this.msg; },
    'toString()Ljava/lang/String;'() { return name + (this.msg ? ': ' + this.msg : ''); },
    'printStackTrace()V'() { console.warn('Java exception', name, this.msg, this.jsStack || ''); },
  } });
}
exc('java/lang/Throwable', null);
exc('java/lang/Exception', 'java/lang/Throwable');
exc('java/lang/Error', 'java/lang/Throwable');
exc('java/lang/OutOfMemoryError', 'java/lang/Error');
exc('java/lang/StackOverflowError', 'java/lang/Error');
exc('java/lang/RuntimeException', 'java/lang/Exception');
exc('java/lang/NullPointerException', 'java/lang/RuntimeException');
exc('java/lang/ArithmeticException', 'java/lang/RuntimeException');
exc('java/lang/IndexOutOfBoundsException', 'java/lang/RuntimeException');
exc('java/lang/ArrayIndexOutOfBoundsException', 'java/lang/IndexOutOfBoundsException');
exc('java/lang/StringIndexOutOfBoundsException', 'java/lang/IndexOutOfBoundsException');
exc('java/lang/NegativeArraySizeException', 'java/lang/RuntimeException');
exc('java/lang/IllegalArgumentException', 'java/lang/RuntimeException');
exc('java/lang/NumberFormatException', 'java/lang/IllegalArgumentException');
exc('java/lang/InterruptedException', 'java/lang/Exception');
exc('java/io/IOException', 'java/lang/Exception');
exc('java/io/EOFException', 'java/io/IOException');
exc('javax/microedition/io/ConnectionNotFoundException', 'java/io/IOException');
exc('javax/microedition/midlet/MIDletStateChangeException', 'java/lang/Exception');
exc('javax/microedition/rms/RecordStoreException', 'java/lang/Exception');
exc('javax/microedition/rms/RecordStoreNotFoundException', 'javax/microedition/rms/RecordStoreException');
exc('javax/microedition/media/MediaException', 'java/lang/Exception');

function jthrow(name, msg) {
  const e = classes[name].$new(); e['<init>()V'](); if (msg) e.msg = msg; throw e;
}
$rt.jthrow = jthrow;
$rt.debug = /[?&]debug/.test(location.search);
$rt.wrapEx = function (ex) {
  if (ex && ex.constructor && ex.constructor.$names) { if ($rt.debug) console.warn('[java throw]', ex.constructor.$name, ex.msg, new Error().stack.split('\n').slice(2, 5).join(' | ')); return ex; }
  if ($rt.debug) console.warn('[js error]', ex && ex.stack);
  const e = classes[ex instanceof RangeError ? 'java/lang/StackOverflowError' : 'java/lang/NullPointerException'].$new();
  e['<init>()V'](); e.msg = String(ex && ex.message); e.jsStack = ex && ex.stack;
  if (!(ex instanceof TypeError || ex instanceof RangeError)) { console.error('[rt] unexpected JS error', ex); }
  return e;
};
$rt.aioobe = function (a, i) { if (a == null) jthrow('java/lang/NullPointerException'); jthrow('java/lang/ArrayIndexOutOfBoundsException', String(i)); };
$rt.div0 = function () { jthrow('java/lang/ArithmeticException', '/ by zero'); };
$rt.negsize = function () { jthrow('java/lang/NegativeArraySizeException'); };

// ---------------------------------------------------------------- arrays & long ops
$rt.newObjArray = n => new Array(n).fill(null);
$rt.arrayClass = d => ({ $name: d });
function ctor(code) { return { Z: Int8Array, B: Int8Array, C: Uint16Array, S: Int16Array, I: Int32Array, J: Float64Array }[code]; }
$rt.multiArray = function (desc, dims) {
  const lvl = (d, k) => {
    const n = dims[k];
    if (n < 0) $rt.negsize();
    const rest = d.slice(1);               // element descriptor
    if (k === dims.length - 1) { const C = rest.length === 1 ? ctor(rest) : null; return C ? new C(n) : new Array(n).fill(null); }
    const a = new Array(n); for (let i = 0; i < n; i++) a[i] = lvl(rest, k + 1); return a;
  };
  return lvl(desc, 0);
};
$rt.ladd = (a, b) => a + b; $rt.lsub = (a, b) => a - b;
$rt.lmul = (a, b) => { const r = a * b; return Number.isSafeInteger(r) ? r : Number(BigInt.asIntN(64, BigInt(a) * BigInt(b))); };
$rt.lshl = (a, b) => Number(BigInt.asIntN(64, BigInt(a) << BigInt(b & 63)));
$rt.lshr = (a, b) => Number(BigInt(a) >> BigInt(b & 63));
$rt.lushr = (a, b) => Number(BigInt.asIntN(64, BigInt.asUintN(64, BigInt(a)) >> BigInt(b & 63)));
$rt.land = (a, b) => Number(BigInt(a) & BigInt(b)); $rt.lor = (a, b) => Number(BigInt(a) | BigInt(b)); $rt.lxor = (a, b) => Number(BigInt(a) ^ BigInt(b));
$rt.l2i = x => x | 0;

// ---------------------------------------------------------------- java.lang
JObject.prototype['<init>()V'] = function () {};
JObject.prototype['getClass()Ljava/lang/Class;'] = function () { return classes['java/lang/Class'].$new(); };
JObject.prototype['hashCode()I'] = function () { return 0; };
JObject.prototype['equals(Ljava/lang/Object;)Z'] = function (o) { return this === o ? 1 : 0; };
classes['java/lang/Object'] = JObject;

def('java/lang/Class', { i: {
  'getResourceAsStream(Ljava/lang/String;)Ljava/io/InputStream;'(n) {
    const r = $rt.res[n[0] === '/' ? n : '/' + n]; if (!r) return null;
    const s = classes['java/io/ByteArrayInputStream'].$new(); s['<init>([B)V'](r); return s;
  },
} });

const SP = String.prototype;
SP['charAt(I)C'] = function (i) { const c = this.charCodeAt(i); if (c !== c) jthrow('java/lang/StringIndexOutOfBoundsException', String(i)); return c; };
SP['equals(Ljava/lang/Object;)Z'] = function (o) { return (typeof o === 'string' && o === this.valueOf()) ? 1 : 0; };
SP['indexOf(Ljava/lang/String;)I'] = function (s) { return this.indexOf(s); };
SP['indexOf(Ljava/lang/String;I)I'] = function (s, i) { return this.indexOf(s, i); };
SP['length()I'] = function () { return this.length; };
SP['startsWith(Ljava/lang/String;I)Z'] = function (s, i) { return this.startsWith(s, i) ? 1 : 0; };
SP['substring(I)Ljava/lang/String;'] = function (a) { if (a < 0 || a > this.length) jthrow('java/lang/StringIndexOutOfBoundsException', String(a)); return this.substring(a); };
SP['substring(II)Ljava/lang/String;'] = function (a, b) { if (a < 0 || b > this.length || a > b) jthrow('java/lang/StringIndexOutOfBoundsException', a + ',' + b); return this.substring(a, b); };
SP['hashCode()I'] = function () { let h = 0; for (let i = 0; i < this.length; i++) h = (Math.imul(31, h) + this.charCodeAt(i)) | 0; return h; };
SP['toString()Ljava/lang/String;'] = function () { return this.valueOf(); };
SP['getClass()Ljava/lang/Class;'] = function () { return classes['java/lang/Class'].$new(); };

def('java/lang/StringBuffer', { fields: [], i: {
  '<init>()V'() { this.s = ''; }, '<init>(I)V'() { this.s = ''; }, '<init>(Ljava/lang/String;)V'(x) { this.s = x; },
  'append(I)Ljava/lang/StringBuffer;'(n) { this.s += n; return this; },
  'append(Ljava/lang/String;)Ljava/lang/StringBuffer;'(x) { this.s += (x === null ? 'null' : x); return this; },
  'append(C)Ljava/lang/StringBuffer;'(c) { this.s += String.fromCharCode(c); return this; },
  'capacity()I'() { return Math.max(16, this.s.length); },
  'deleteCharAt(I)Ljava/lang/StringBuffer;'(i) { if (i < 0 || i >= this.s.length) jthrow('java/lang/StringIndexOutOfBoundsException'); this.s = this.s.slice(0, i) + this.s.slice(i + 1); return this; },
  'getChars(II[CI)V'(a, b, dst, d) { for (let i = a; i < b; i++) dst[d + i - a] = this.s.charCodeAt(i); },
  'insert(IC)Ljava/lang/StringBuffer;'(i, c) { this.s = this.s.slice(0, i) + String.fromCharCode(c) + this.s.slice(i); return this; },
  'length()I'() { return this.s.length; },
  'setCharAt(IC)V'(i, c) { this.s = this.s.slice(0, i) + String.fromCharCode(c) + this.s.slice(i + 1); },
  'toString()Ljava/lang/String;'() { return this.s; },
} });

def('java/lang/Integer', { i: {
  '<init>(I)V'(v) { this.value = v; }, 'intValue()I'() { return this.value; },
  'hashCode()I'() { return this.value; },
  'equals(Ljava/lang/Object;)Z'(o) { return (o && o.value === this.value && o.constructor === this.constructor) ? 1 : 0; },
}, s: {
  'parseInt(Ljava/lang/String;)I'(s) { if (s === null || !/^[+-]?\d+$/.test(s)) jthrow('java/lang/NumberFormatException', s); return parseInt(s, 10) | 0; },
  'toString(I)Ljava/lang/String;'(n) { return String(n); },
} });

def('java/lang/Math', { s: {
  'abs(I)I'(a) { return a < 0 ? (-a) | 0 : a; }, 'max(II)I'(a, b) { return a > b ? a : b; }, 'min(II)I'(a, b) { return a < b ? a : b; },
} });

def('java/lang/System', { s: {
  'arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V'(src, sp, dst, dp, n) {
    if (src == null || dst == null) jthrow('java/lang/NullPointerException');
    if (sp < 0 || dp < 0 || n < 0 || sp + n > src.length || dp + n > dst.length) jthrow('java/lang/ArrayIndexOutOfBoundsException');
    if (ArrayBuffer.isView(src) && ArrayBuffer.isView(dst)) { dst.set(src.subarray(sp, sp + n), dp); return; }
    if (src === dst && sp < dp) for (let i = n - 1; i >= 0; i--) dst[dp + i] = src[sp + i];
    else for (let i = 0; i < n; i++) dst[dp + i] = src[sp + i];
  },
  'currentTimeMillis()J'() { return Date.now(); },
  'gc()V'() {},
  'getProperty(Ljava/lang/String;)Ljava/lang/String;'(k) { return $rt.props[k] === undefined ? null : $rt.props[k]; },
} });

def('java/lang/Thread', { i: {
  '<init>(Ljava/lang/Runnable;)V'(r) { this.r = r; },
  'start()V'() { const r = this.r; setTimeout(() => { try { r['run()V'](); } catch (e) { console.warn('thread died', e); } }, 0); },
  'join()V'() {},
}, s: { 'sleep(J)V'() {} } });

// ---------------------------------------------------------------- java.io
def('java/io/InputStream', { i: {
  '<init>()V'() {}, 'close()V'() {},
  'read([BII)I'(b, off, len) {
    let n = 0;
    while (n < len) { const c = this['read()I'](); if (c < 0) break; b[off + n++] = c; }
    return n === 0 && len > 0 ? -1 : n;
  },
} });
def('java/io/ByteArrayInputStream', { sup: 'java/io/InputStream', i: {
  '<init>([B)V'(b) { this.buf = b; this.pos = 0; },
  'read()I'() { return this.pos < this.buf.length ? this.buf[this.pos++] & 255 : -1; },
  'read([BII)I'(b, off, len) {
    const n = Math.min(len, this.buf.length - this.pos); if (n <= 0) return len === 0 ? 0 : -1;
    for (let i = 0; i < n; i++) b[off + i] = this.buf[this.pos + i];
    this.pos += n; return n;
  },
} });
def('java/io/DataInputStream', { sup: 'java/io/InputStream', i: {
  '<init>(Ljava/io/InputStream;)V'(s) { this.in = s; },
  'read()I'() { return this.in['read()I'](); },
  'close()V'() { this.in['close()V'](); },
  rb() { const c = this.in['read()I'](); if (c < 0) jthrow('java/io/EOFException'); return c; },
  'readBoolean()Z'() { return this.rb() !== 0 ? 1 : 0; },
  'readByte()B'() { return this.rb() << 24 >> 24; },
  'readChar()C'() { return (this.rb() << 8) | this.rb(); },
  'readShort()S'() { return ((this.rb() << 8) | this.rb()) << 16 >> 16; },
  'readInt()I'() { return (this.rb() << 24) | (this.rb() << 16) | (this.rb() << 8) | this.rb(); },
  'readUTF()Ljava/lang/String;'() {
    const n = (this.rb() << 8) | this.rb(); let s = '';
    for (let i = 0; i < n;) {
      const c = this.rb(); i++;
      if (c < 0x80) s += String.fromCharCode(c);
      else if ((c & 0xE0) === 0xC0) { const d = this.rb(); i++; s += String.fromCharCode(((c & 0x1F) << 6) | (d & 0x3F)); }
      else { const d = this.rb(), e = this.rb(); i += 2; s += String.fromCharCode(((c & 0x0F) << 12) | ((d & 0x3F) << 6) | (e & 0x3F)); }
    }
    return s;
  },
} });
def('java/io/OutputStream', { i: { '<init>()V'() {}, 'close()V'() {} } });
def('java/io/ByteArrayOutputStream', { sup: 'java/io/OutputStream', i: {
  '<init>()V'() { this.a = []; },
  'write(I)V'(b) { this.a.push(b & 255); },
  'toByteArray()[B'() { return Int8Array.from(this.a); },
} });
def('java/io/DataOutputStream', { sup: 'java/io/OutputStream', i: {
  '<init>(Ljava/io/OutputStream;)V'(o) { this.o = o; },
  'write(I)V'(b) { this.o['write(I)V'](b); },
  'write([B)V'(b) { for (let i = 0; i < b.length; i++) this.o['write(I)V'](b[i]); },
  'writeBoolean(Z)V'(v) { this.o['write(I)V'](v ? 1 : 0); },
  'writeInt(I)V'(v) { this.o['write(I)V'](v >>> 24); this.o['write(I)V'](v >>> 16); this.o['write(I)V'](v >>> 8); this.o['write(I)V'](v); },
  'writeUTF(Ljava/lang/String;)V'(s) {
    const out = [];
    for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      if (c >= 1 && c < 0x80) out.push(c);
      else if (c < 0x800) out.push(0xC0 | (c >> 6), 0x80 | (c & 63));
      else out.push(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    }
    this.o['write(I)V'](out.length >> 8); this.o['write(I)V'](out.length & 255);
    for (const b of out) this.o['write(I)V'](b);
  },
  'close()V'() {},
} });

// ---------------------------------------------------------------- java.util
const hkey = o => (o && o.constructor && o.constructor.$name === 'java/lang/Integer') ? o.value : o;
def('java/util/Hashtable', { i: {
  '<init>()V'() { this.m = new Map(); },
  'clear()V'() { this.m.clear(); },
  'containsKey(Ljava/lang/Object;)Z'(k) { return this.m.has(hkey(k)) ? 1 : 0; },
  'get(Ljava/lang/Object;)Ljava/lang/Object;'(k) { const v = this.m.get(hkey(k)); return v === undefined ? null : v; },
  'put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;'(k, v) { const o = this.m.get(hkey(k)); this.m.set(hkey(k), v); return o === undefined ? null : o; },
} });
def('java/util/Vector', { i: {
  '<init>()V'() { this.a = []; },
  'addElement(Ljava/lang/Object;)V'(o) { this.a.push(o); },
  'elementAt(I)Ljava/lang/Object;'(i) { if (i < 0 || i >= this.a.length) jthrow('java/lang/ArrayIndexOutOfBoundsException'); return this.a[i]; },
  'removeAllElements()V'() { this.a.length = 0; },
  'size()I'() { return this.a.length; },
} });

// ---------------------------------------------------------------- PNG decoding (sync)
function inflate(src, pos) {
  // zlib stream: skip 2-byte header
  pos += 2;
  let out = new Uint8Array(Math.max(1024, src.length * 4)), op = 0, bitBuf = 0, bitCnt = 0;
  const need = n => { if (op + n > out.length) { const o = new Uint8Array(Math.max(out.length * 2, op + n)); o.set(out); out = o; } };
  const bits = n => { while (bitCnt < n) { bitBuf |= src[pos++] << bitCnt; bitCnt += 8; } const v = bitBuf & ((1 << n) - 1); bitBuf >>>= n; bitCnt -= n; return v; };
  const build = lens => {
    const count = new Uint16Array(16), offs = new Uint16Array(16), sym = new Uint16Array(lens.length);
    for (const l of lens) count[l]++; count[0] = 0;
    for (let i = 1; i < 16; i++) offs[i] = offs[i - 1] + count[i - 1];
    for (let i = 0; i < lens.length; i++) if (lens[i]) sym[offs[lens[i]]++] = i;
    return { count, sym };
  };
  const decode = h => {
    let code = 0, first = 0, index = 0;
    for (let len = 1; len < 16; len++) {
      code |= bits(1); const c = h.count[len];
      if (code - c < first) return h.sym[index + (code - first)];
      index += c; first += c; first <<= 1; code <<= 1;
    }
    throw new Error('bad huffman code');
  };
  const LB = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258], LE = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  const DB = [1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577], DE = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
  let fixedL = null, fixedD = null, last;
  do {
    last = bits(1); const type = bits(2);
    if (type === 0) {
      bitBuf = 0; bitCnt = 0;
      const len = src[pos] | (src[pos + 1] << 8); pos += 4; need(len);
      out.set(src.subarray(pos, pos + len), op); op += len; pos += len;
    } else {
      let hl, hd;
      if (type === 1) {
        if (!fixedL) { const l = new Uint8Array(288); l.fill(8, 0, 144); l.fill(9, 144, 256); l.fill(7, 256, 280); l.fill(8, 280); fixedL = build(l); fixedD = build(new Uint8Array(30).fill(5)); }
        hl = fixedL; hd = fixedD;
      } else {
        const nl = bits(5) + 257, nd = bits(5) + 1, nc = bits(4) + 4;
        const ord = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15], cl = new Uint8Array(19);
        for (let i = 0; i < nc; i++) cl[ord[i]] = bits(3);
        const ch = build(cl), lens = new Uint8Array(nl + nd);
        for (let i = 0; i < nl + nd;) {
          const s = decode(ch);
          if (s < 16) lens[i++] = s;
          else { let p = 0, r; if (s === 16) { p = lens[i - 1]; r = 3 + bits(2); } else if (s === 17) r = 3 + bits(3); else r = 11 + bits(7); while (r--) lens[i++] = p; }
        }
        hl = build(lens.subarray(0, nl)); hd = build(lens.subarray(nl));
      }
      for (;;) {
        let s = decode(hl);
        if (s < 256) { need(1); out[op++] = s; }
        else if (s === 256) break;
        else {
          s -= 257; const len = LB[s] + bits(LE[s]); const ds = decode(hd); const dist = DB[ds] + bits(DE[ds]);
          need(len); for (let i = 0; i < len; i++, op++) out[op] = out[op - dist];
        }
      }
    }
  } while (!last);
  return out.subarray(0, op);
}
function decodePNG(b) { // b: Int8Array/Uint8Array
  const u = b instanceof Uint8Array ? b : new Uint8Array(b.buffer, b.byteOffset, b.length);
  if (u[0] !== 0x89 || u[1] !== 0x50) throw new Error('not a PNG');
  let p = 8, w = 0, h = 0, bd = 8, ct = 0, pal = null, trns = null; const idat = [];
  const dv = new DataView(u.buffer, u.byteOffset, u.length);
  while (p < u.length) {
    const len = dv.getUint32(p), type = String.fromCharCode(u[p + 4], u[p + 5], u[p + 6], u[p + 7]), d = p + 8;
    if (type === 'IHDR') { w = dv.getUint32(d); h = dv.getUint32(d + 4); bd = u[d + 8]; ct = u[d + 9]; if (u[d + 12]) throw new Error('interlaced PNG unsupported'); }
    else if (type === 'PLTE') pal = u.subarray(d, d + len);
    else if (type === 'tRNS') trns = u.subarray(d, d + len);
    else if (type === 'IDAT') idat.push(u.subarray(d, d + len));
    else if (type === 'IEND') break;
    p = d + len + 4;
  }
  let tot = 0; for (const c of idat) tot += c.length;
  const z = new Uint8Array(tot); { let o = 0; for (const c of idat) { z.set(c, o); o += c.length; } }
  const raw = inflate(z, 0);
  const chans = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[ct], bpp = Math.max(1, (chans * bd) >> 3), stride = (w * chans * bd + 7) >> 3;
  const img = new Uint8Array(stride * h); let rp = 0;
  for (let y = 0; y < h; y++) {
    const ft = raw[rp++], row = y * stride, prev = row - stride;
    for (let x = 0; x < stride; x++) {
      const a = x >= bpp ? img[row + x - bpp] : 0, up = y ? img[prev + x] : 0, c = (x >= bpp && y) ? img[prev + x - bpp] : 0;
      let v = raw[rp++];
      if (ft === 1) v += a; else if (ft === 2) v += up; else if (ft === 3) v += (a + up) >> 1;
      else if (ft === 4) { const pp = a + up - c, pa = Math.abs(pp - a), pb = Math.abs(pp - up), pc = Math.abs(pp - c); v += (pa <= pb && pa <= pc) ? a : (pb <= pc ? up : c); }
      img[row + x] = v & 255;
    }
  }
  const rgba = new Uint8ClampedArray(w * h * 4);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const o = (y * w + x) * 4; let r, g, bl, al = 255;
    if (ct === 6) { const s = y * stride + x * 4; r = img[s]; g = img[s + 1]; bl = img[s + 2]; al = img[s + 3]; }
    else if (ct === 2) { const s = y * stride + x * 3; r = img[s]; g = img[s + 1]; bl = img[s + 2]; }
    else if (ct === 3) {
      let idx; if (bd === 8) idx = img[y * stride + x]; else { const bi = x * bd, v = img[y * stride + (bi >> 3)]; idx = (v >> (8 - bd - (bi & 7))) & ((1 << bd) - 1); }
      r = pal[idx * 3]; g = pal[idx * 3 + 1]; bl = pal[idx * 3 + 2]; al = trns && idx < trns.length ? trns[idx] : 255;
    } else if (ct === 0) { const v = img[y * stride + x]; r = g = bl = v; }
    else { const s = y * stride + x * 2; r = g = bl = img[s]; al = img[s + 1]; }
    rgba[o] = r; rgba[o + 1] = g; rgba[o + 2] = bl; rgba[o + 3] = al;
  }
  return { w, h, rgba };
}
$rt.decodePNG = decodePNG;

// ---------------------------------------------------------------- lcdui
function mkCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
def('javax/microedition/lcdui/Image', { i: {
  'getWidth()I'() { return this.w; }, 'getHeight()I'() { return this.h; },
}, s: {
  'createImage([BII)Ljavax/microedition/lcdui/Image;'(b, off, len) {
    const png = decodePNG(b.subarray(off, off + len));
    const c = mkCanvas(png.w, png.h), x = c.getContext('2d');
    x.putImageData(new ImageData(png.rgba, png.w, png.h), 0, 0);
    const im = classes['javax/microedition/lcdui/Image'].$new(); im.c = c; im.w = png.w; im.h = png.h;
    let hh = 0; for (let i = off, e = off + len; i < e; i++) hh = (Math.imul(hh, 31) + b[i]) | 0;
    im.k = png.w + 'x' + png.h + '_' + (hh >>> 0).toString(16).padStart(8, '0');
    if ($rt.imgHook) $rt.imgHook(im, b, off, len);
    return im;
  },
} });

const fontMeasure = document.createElement('canvas').getContext('2d');
def('javax/microedition/lcdui/Font', { i: {
  'getHeight()I'() { return this.hgt; },
  'charWidth(C)I'(c) { fontMeasure.font = this.css; return Math.round(fontMeasure.measureText(String.fromCharCode(c)).width); },
  'stringWidth(Ljava/lang/String;)I'(s) { fontMeasure.font = this.css; return Math.round(fontMeasure.measureText(s).width); },
}, s: {
  'getFont(III)Ljavax/microedition/lcdui/Font;'(face, style, size) {
    const f = classes['javax/microedition/lcdui/Font'].$new();
    const px = size === 8 ? 10 : size === 16 ? 16 : 12;
    f.px = px; f.hgt = Math.ceil(px * 1.2); f.css = (style & 1 ? 'bold ' : '') + (style & 2 ? 'italic ' : '') + px + 'px sans-serif'; return f;
  },
} });

const hex = n => '#' + (n & 0xFFFFFF).toString(16).padStart(6, '0');
const G = def('javax/microedition/lcdui/Graphics', { i: {
  ap() { if (this.dirty) { const x = this.x, c = this.clip; x.restore(); x.save(); if (this.xf) { x.translate(this.xf[0], this.xf[1]); x.scale(this.xf[2], this.xf[2]); } x.beginPath(); x.rect(c[0], c[1], c[2], c[3]); x.clip(); x.fillStyle = this.fs; this.dirty = false; } },
  'setColor(I)V'(rgb) { this.color = rgb & 0xFFFFFF; this.fs = hex(rgb); this.x.fillStyle = this.fs; },
  'setColor(III)V'(r, g, b) { this['setColor(I)V']((r << 16) | (g << 8) | b); },
  'getColor()I'() { return this.color; },
  'setFont(Ljavax/microedition/lcdui/Font;)V'(f) { this.font = f; },
  'setClip(IIII)V'(x, y, w, h) { this.clip = [x, y, w, h]; this.dirty = true; },
  'getClipX()I'() { return this.clip[0]; }, 'getClipY()I'() { return this.clip[1]; },
  'getClipWidth()I'() { return this.clip[2]; }, 'getClipHeight()I'() { return this.clip[3]; },
  'fillRect(IIII)V'(x, y, w, h) { if (w <= 0 || h <= 0) return; if (this.dirty) this.ap(); this.x.fillRect(x, y, w, h); },
  'drawRect(IIII)V'(x, y, w, h) {
    if (w < 0 || h < 0) return; if (this.dirty) this.ap(); const c = this.x;
    c.fillRect(x, y, w + 1, 1); if (h > 0) c.fillRect(x, y + h, w + 1, 1);
    if (h > 1) { c.fillRect(x, y + 1, 1, h - 1); if (w > 0) c.fillRect(x + w, y + 1, 1, h - 1); }
  },
  'drawLine(IIII)V'(x1, y1, x2, y2) {
    if (this.dirty) this.ap(); const c = this.x;
    if (y1 === y2) { c.fillRect(Math.min(x1, x2), y1, Math.abs(x2 - x1) + 1, 1); return; }
    if (x1 === x2) { c.fillRect(x1, Math.min(y1, y2), 1, Math.abs(y2 - y1) + 1); return; }
    let dx = Math.abs(x2 - x1), dy = -Math.abs(y2 - y1), sx = x1 < x2 ? 1 : -1, sy = y1 < y2 ? 1 : -1, e = dx + dy;
    for (;;) { c.fillRect(x1, y1, 1, 1); if (x1 === x2 && y1 === y2) break; const e2 = 2 * e; if (e2 >= dy) { e += dy; x1 += sx; } if (e2 <= dx) { e += dx; y1 += sy; } }
  },
  'fillArc(IIIIII)V'(x, y, w, h, s, a) {
    if (w <= 0 || h <= 0) return; if (this.dirty) this.ap(); const c = this.x;
    c.beginPath(); c.moveTo(x + w / 2, y + h / 2);
    if (Math.abs(a) >= 360) c.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
    else c.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, -s * Math.PI / 180, -(s + a) * Math.PI / 180, a > 0);
    c.closePath(); c.fill();
  },
  dstr(s, x, y, anchor) {
    if (this.dirty) this.ap(); const c = this.x;
    const fo = this.font || (this.font = classes['javax/microedition/lcdui/Font']['getFont(III)Ljavax/microedition/lcdui/Font;'](0, 0, 0));
    c.font = fo.css; const w = c.measureText(s).width;
    if (anchor & 1) x -= w / 2; else if (anchor & 8) x -= w;
    c.textBaseline = 'alphabetic';
    if (anchor & 16) y += fo.px; else if (anchor & 32) y -= (fo.hgt - fo.px);
    c.fillText(s, x, y);
  },
  'drawString(Ljava/lang/String;III)V'(s, x, y, a) { this.dstr(s, x, y, a); },
  'drawChar(CIII)V'(ch, x, y, a) { this.dstr(String.fromCharCode(ch), x, y, a); },
  'drawImage(Ljavax/microedition/lcdui/Image;III)V'(im, x, y, a) {
    if (!im) jthrow('java/lang/NullPointerException'); if (this.dirty) this.ap();
    if (a & 1) x -= im.w >> 1; else if (a & 8) x -= im.w;
    if (a & 2) y -= im.h >> 1; else if (a & 32) y -= im.h;
    const hi = $rt.hires && $rt.hires[im.k];
    if (hi && hi.complete && hi.naturalWidth) this.x.drawImage(hi, x, y, im.w, im.h); else this.x.drawImage(im.c, x, y);
  },
} });
$rt.makeGraphics = function (ctx, w, h) {
  const g = G.$new(); g.x = ctx; g.clip = [0, 0, w, h]; g.color = 0; g.fs = '#000000'; g.dirty = true; g.font = null; ctx.save(); return g;
};

def('com/nokia/mid/ui/DirectGraphics', { i: {
  'drawImage(Ljavax/microedition/lcdui/Image;IIII)V'(im, x, y, anchor, man) {
    const g = this.g; if (g.dirty) g.ap(); const c = g.x;
    if (anchor & 1) x -= im.w >> 1; else if (anchor & 8) x -= im.w;
    if (anchor & 2) y -= im.h >> 1; else if (anchor & 32) y -= im.h;
    c.save(); c.translate(x + im.w / 2, y + im.h / 2);
    if (man & 0x2000) c.scale(-1, 1); if (man & 0x4000) c.scale(1, -1);
    const rot = man & 0x1FF; if (rot) c.rotate(-rot * Math.PI / 180);
    const hi = $rt.hires && $rt.hires[im.k];
    if (hi && hi.complete && hi.naturalWidth) c.drawImage(hi, -im.w / 2, -im.h / 2, im.w, im.h); else c.drawImage(im.c, -im.w / 2, -im.h / 2);
    c.restore();
  },
} });
def('com/nokia/mid/ui/DirectUtils', { s: {
  'getDirectGraphics(Ljavax/microedition/lcdui/Graphics;)Lcom/nokia/mid/ui/DirectGraphics;'(g) {
    const d = classes['com/nokia/mid/ui/DirectGraphics'].$new(); d.g = g; return d;
  },
} });

def('javax/microedition/lcdui/Displayable', { i: { '<init>()V'() {}, 'setCommandListener(Ljavax/microedition/lcdui/CommandListener;)V'() {}, 'addCommand(Ljavax/microedition/lcdui/Command;)V'() {} } });
def('javax/microedition/lcdui/Canvas', { sup: 'javax/microedition/lcdui/Displayable', i: {
  '<init>()V'() {},
  'getWidth()I'() { return $rt.screen.w; }, 'getHeight()I'() { return $rt.screen.h; },
  'repaint()V'() { this.needs = true; },
  'serviceRepaints()V'() { $rt.paintNow(this); },
  'setFullScreenMode(Z)V'() {},
  'getGameAction(I)I'(k) {
    switch (k) { case -1: case 50: return 1; case -2: case 56: return 6; case -3: case 52: return 2; case -4: case 54: return 5; case -5: case 53: return 8; default: return 0; }
  },
  'getKeyCode(I)I'(a) { return { 1: -1, 6: -2, 2: -3, 5: -4, 8: -5 }[a] || 0; },
} });
def('com/nokia/mid/ui/FullCanvas', { sup: 'javax/microedition/lcdui/Canvas', i: { '<init>()V'() {} } });
def('javax/microedition/lcdui/Item', { i: {} });
def('javax/microedition/lcdui/TextField', { sup: 'javax/microedition/lcdui/Item', i: {
  '<init>(Ljava/lang/String;Ljava/lang/String;II)V'(l, t) { this.t = t || ''; }, 'getString()Ljava/lang/String;'() { return this.t; } } });
def('javax/microedition/lcdui/Command', { i: { '<init>(Ljava/lang/String;II)V'() {} } });
def('javax/microedition/lcdui/Form', { sup: 'javax/microedition/lcdui/Displayable', i: {
  '<init>(Ljava/lang/String;)V'() {},
  'append(Ljava/lang/String;)I'() { return 0; }, 'append(Ljavax/microedition/lcdui/Item;)I'() { return 0; },
} });

const display = (() => {
  const queue = [];
  const D = def('javax/microedition/lcdui/Display', { i: {
    'callSerially(Ljava/lang/Runnable;)V'(r) { queue.push(r); },
    'setCurrent(Ljavax/microedition/lcdui/Displayable;)V'(d) { if (d && d['paint(Ljavax/microedition/lcdui/Graphics;)V']) $rt.current = d; },
  }, s: { 'getDisplay(Ljavax/microedition/midlet/MIDlet;)Ljavax/microedition/lcdui/Display;'() { return display; } } });
  const inst = D.$new(); inst.queue = queue; return inst;
})();

def('javax/microedition/midlet/MIDlet', { i: {
  '<init>()V'() {}, 'notifyDestroyed()V'() { $rt.running = false; },
  'getAppProperty(Ljava/lang/String;)Ljava/lang/String;'(k) { return $rt.props[k] === undefined ? null : $rt.props[k]; },
  'startApp()V'() {}, 'pauseApp()V'() {}, 'destroyApp(Z)V'() {},
} });

// ---------------------------------------------------------------- RMS (localStorage)
const b64 = {
  enc(a) { let s = ''; for (let i = 0; i < a.length; i++) s += String.fromCharCode(a[i] & 255); return btoa(s); },
  dec(t) { const s = atob(t), a = new Int8Array(s.length); for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; },
};
const lsGet = k => { try { return localStorage.getItem(k); } catch (e) { return mem[k] || null; } };
const mem = {};
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { mem[k] = v; } };
const lsDel = k => { try { localStorage.removeItem(k); } catch (e) { delete mem[k]; } };
def('javax/microedition/rms/RecordStore', { i: {
  'addRecord([BII)I'(b, off, len) { this.recs.push(b.slice(off, off + len)); this.save(); return this.recs.length; },
  'getRecord(I)[B'(i) { const r = this.recs[i - 1]; if (!r) jthrow('javax/microedition/rms/RecordStoreException'); return r.slice(); },
  'closeRecordStore()V'() {},
  save() { lsSet('kr:rs:' + this.name, JSON.stringify(this.recs.map(r => b64.enc(r)))); },
}, s: {
  'openRecordStore(Ljava/lang/String;Z)Ljavax/microedition/rms/RecordStore;'(n, create) {
    const raw = lsGet('kr:rs:' + n);
    if (raw === null && !create) jthrow('javax/microedition/rms/RecordStoreNotFoundException', n);
    const rs = classes['javax/microedition/rms/RecordStore'].$new(); rs.name = n;
    rs.recs = raw ? JSON.parse(raw).map(b64.dec) : []; if (raw === null) rs.save(); return rs;
  },
  'deleteRecordStore(Ljava/lang/String;)V'(n) { if (lsGet('kr:rs:' + n) === null) jthrow('javax/microedition/rms/RecordStoreNotFoundException', n); lsDel('kr:rs:' + n); },
} });

// ---------------------------------------------------------------- media (hooks to $rt.audio)
def('javax/microedition/media/control/VolumeControl', { i: { 'setLevel(I)I'(l) { this.level = l; if (this.pl) this.pl.vol(l); return l; } } });
def('javax/microedition/media/Player', { i: {
  'addPlayerListener(Ljavax/microedition/media/PlayerListener;)V'() {},
  'close()V'() { this.state = 0; if ($rt.audio) $rt.audio.stop(this); },
  'getControl(Ljava/lang/String;)Ljavax/microedition/media/Control;'() { const v = classes['javax/microedition/media/control/VolumeControl'].$new(); v.pl = this; return v; },
  'getState()I'() { return this.state; },
  'prefetch()V'() { this.state = 300; },
  'setLoopCount(I)V'(n) { this.loops = n; },
  'start()V'() { this.state = 400; if ($rt.audio) $rt.audio.play(this); },
  vol(l) { this.level = l; if ($rt.audio && $rt.audio.setVolume) $rt.audio.setVolume(this, l); },
} });
def('javax/microedition/media/Manager', { s: {
  'createPlayer(Ljava/io/InputStream;Ljava/lang/String;)Ljavax/microedition/media/Player;'(is, type) {
    const bytes = []; let c; while ((c = is['read()I']()) >= 0) bytes.push(c);
    const p = classes['javax/microedition/media/Player'].$new(); p.bytes = Uint8Array.from(bytes); p.type = type; p.state = 200; p.loops = 1; p.level = 100; return p;
  },
} });

// ---------------------------------------------------------------- network / SMS: unavailable on the web
def('javax/microedition/io/Connector', { s: { 'open(Ljava/lang/String;)Ljavax/microedition/io/Connection;'(u) { jthrow('javax/microedition/io/ConnectionNotFoundException', u); } } });
def('javax/microedition/io/HttpConnection', { i: {
  'close()V'() {}, 'openDataInputStream()Ljava/io/DataInputStream;'() { jthrow('java/io/IOException'); },
  'openDataOutputStream()Ljava/io/DataOutputStream;'() { jthrow('java/io/IOException'); },
  'setRequestMethod(Ljava/lang/String;)V'() {}, 'setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V'() {},
} });
def('javax/wireless/messaging/MessageConnection', { i: { 'close()V'() {}, 'newMessage(Ljava/lang/String;)Ljavax/wireless/messaging/Message;'() { jthrow('java/io/IOException'); }, 'send(Ljavax/wireless/messaging/Message;)V'() { jthrow('java/io/IOException'); } } });
def('javax/wireless/messaging/TextMessage', { i: { 'setAddress(Ljava/lang/String;)V'() {}, 'setPayloadText(Ljava/lang/String;)V'() {} } });

// ---------------------------------------------------------------- host loop
$rt.checkRefs = function () {
  const missing = [];
  for (const [o, k, t] of $rt.rtRefs) {
    const K = o === 'java/lang/String' ? { prototype: String.prototype } : classes[o];
    if (!K) { missing.push(o + ' (class)'); continue; }
    if (t === 's' ? typeof K[k] !== 'function' : typeof K.prototype[k] !== 'function') missing.push(o + '.' + k);
  }
  return missing;
};
$rt.paintNow = function (canvas) {
  const sc = $rt.screenCanvas, g = $rt.gfx;
  if (!g) return;
  if ($rt.onFrame) $rt.onFrame();
  g.x.restore(); g.x.save(); g.clip = [0, 0, $rt.screen.w, $rt.screen.h]; g.dirty = true;
  canvas['paint(Ljavax/microedition/lcdui/Graphics;)V'](g);
};
$rt.setScreen = function (w, h, k) {
  k = k || $rt.screen.k || 1;
  $rt.screen.w = w; $rt.screen.h = h; $rt.screen.k = k;
  const sc = $rt.screenCanvas;
  if (sc.width !== w * k || sc.height !== h * k) { sc.width = w * k; sc.height = h * k; }
  const ctx = sc.getContext('2d', { alpha: false }); ctx.setTransform(k, 0, 0, k, 0, 0); ctx.imageSmoothingEnabled = false;   // game draws in logical px; backing store is k times denser (smooth text)
  $rt.gfx = $rt.makeGraphics(ctx, w, h);
};
$rt.key = function (type, code) {
  const c = $rt.current; if (!c) return;
  try { c[type === 'down' ? 'keyPressed(I)V' : 'keyReleased(I)V'](code); } catch (e) { console.warn('key handler', e); }
};
$rt.perf = { ms: 0, n: 0, max: 0 };
$rt.start = function (canvasEl, resMap, props) {
  $rt.screenCanvas = canvasEl; $rt.res = resMap; $rt.props = props || {};
  const missing = $rt.checkRefs(); if (missing.length) console.error('[rt] MISSING', missing);
  $rt.setScreen($rt.screen.w, $rt.screen.h);
  const Main = classes['DCBolt']; Main.$init && Main.$init();
  const m = Main.$new(); m['<init>()V']();
  $rt.midlet = m; $rt.running = true;
  m['startApp()V']();
  let frames = 0;
  const tick = () => {
    if (!$rt.running) return;
    const q = display.queue.splice(0, display.queue.length), t0 = performance.now();
    for (const r of q) { try { r['run()V'](); } catch (e) { console.error('run() error', $rt.wrapEx(e)); } }
    const dt = performance.now() - t0; $rt.perf.ms += dt; $rt.perf.n++; if (dt > $rt.perf.max) $rt.perf.max = dt;
    frames++; requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
};
})(typeof window !== 'undefined' ? window : globalThis);
