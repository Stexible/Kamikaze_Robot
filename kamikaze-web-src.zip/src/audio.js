/* Tiny Standard-MIDI player on WebAudio (chiptune-style voices). Hooks into $rt.audio used by the Player shim. */
(function () {
'use strict';
let ac = null, master = null, noiseBuf = null;
const active = new Map(); // player -> state

function ensure() {
  if (ac) return ac;
  const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null;
  ac = new AC(); master = ac.createGain(); master.gain.value = 0.35; master.connect(ac.destination);
  noiseBuf = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
  const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  return ac;
}
function unlock() { const c = ensure(); if (c && c.state === 'suspended') c.resume(); }
['pointerdown', 'keydown', 'touchstart'].forEach(ev => addEventListener(ev, unlock, { passive: true }));

function parseSMF(u8) {
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.length); let p = 14;
  const fmt = dv.getUint16(8), ntr = dv.getUint16(10), div = dv.getUint16(12);
  const events = [], tempos = [[0, 500000]];
  for (let t = 0; t < ntr; t++) {
    if (dv.getUint32(p) !== 0x4D54726B) break;
    const len = dv.getUint32(p + 4); let q = p + 8; const end = q + len; let tick = 0, run = 0;
    const vlq = () => { let v = 0, b; do { b = u8[q++]; v = (v << 7) | (b & 127); } while (b & 128); return v; };
    while (q < end) {
      tick += vlq(); let st = u8[q];
      if (st === 0xFF) { const ty = u8[q + 1]; q += 2; const l = vlq(); if (ty === 0x51) tempos.push([tick, (u8[q] << 16) | (u8[q + 1] << 8) | u8[q + 2]]); q += l; continue; }
      if (st === 0xF0 || st === 0xF7) { q++; q += vlq(); continue; }
      if (st & 128) { run = st; q++; } else st = run;
      const ch = st & 15, ty = st >> 4;
      if (ty === 0x9 || ty === 0x8) { const n = u8[q++], v = u8[q++]; events.push({ tick, ty: (ty === 0x9 && v > 0) ? 'on' : 'off', ch, n, v }); }
      else if (ty === 0xC) events.push({ tick, ty: 'pc', ch, v: u8[q++] });
      else if (ty === 0xB) { const c = u8[q++], v = u8[q++]; if (c === 7) events.push({ tick, ty: 'vol', ch, v }); }
      else if (ty === 0xD) q++; else q += 2;
    }
    p = end;
  }
  tempos.sort((a, b) => a[0] - b[0]); events.sort((a, b) => a.tick - b.tick);
  // tick -> seconds
  const toSec = tick => { let s = 0, lt = 0, tp = 500000; for (const [tt, v] of tempos) { if (tt > tick) break; s += (tt - lt) * tp / div / 1e6; lt = tt; tp = v; } return s + (tick - lt) * tp / div / 1e6; };
  for (const e of events) e.t = toSec(e.tick);
  const dur = events.length ? events[events.length - 1].t : 0;
  return { events, dur };
}

function voice(prog, ch) {
  if (ch === 9) return null;
  if (prog >= 32 && prog <= 39) return { type: 'triangle', a: 0.005, r: 0.12, g: 0.9 };         // bass
  if (prog >= 80 && prog <= 87) return { type: 'square', a: 0.005, r: 0.1, g: 0.35 };           // lead
  if (prog >= 88 && prog <= 103) return { type: 'sine', a: 0.08, r: 0.4, g: 0.6 };              // pads
  if (prog >= 24 && prog <= 31) return { type: 'sawtooth', a: 0.005, r: 0.12, g: 0.3 };         // guitars
  if (prog >= 56 && prog <= 79) return { type: 'square', a: 0.02, r: 0.12, g: 0.3 };            // brass/reed/pipe
  return { type: 'triangle', a: 0.005, r: 0.2, g: 0.7 };
}
function playNote(st, e, when, dur) {
  const prog = st.prog[e.ch] || 0, vol = (st.cvol[e.ch] === undefined ? 100 : st.cvol[e.ch]) / 127;
  const amp = (e.v / 127) * vol * 0.5;
  if (e.ch === 9) { // percussion
    const n = e.n, src = ac.createBufferSource(), g = ac.createGain();
    if (n === 35 || n === 36) { const o = ac.createOscillator(); o.frequency.setValueAtTime(140, when); o.frequency.exponentialRampToValueAtTime(40, when + 0.12); g.gain.setValueAtTime(amp * 1.2, when); g.gain.exponentialRampToValueAtTime(0.001, when + 0.16); o.connect(g); g.connect(st.out); o.start(when); o.stop(when + 0.2); return; }
    src.buffer = noiseBuf; const f = ac.createBiquadFilter(); f.type = (n === 38 || n === 40) ? 'bandpass' : 'highpass'; f.frequency.value = (n === 38 || n === 40) ? 1800 : 7000;
    const len = (n === 46 || n === 49 || n === 51 || n === 57) ? 0.3 : (n === 38 || n === 40 ? 0.14 : 0.05);
    g.gain.setValueAtTime(amp * 0.8, when); g.gain.exponentialRampToValueAtTime(0.001, when + len);
    src.connect(f); f.connect(g); g.connect(st.out); src.start(when, Math.random() * 0.5); src.stop(when + len + 0.02); return;
  }
  const v = voice(prog, e.ch), o = ac.createOscillator(), g = ac.createGain();
  o.type = v.type; o.frequency.value = 440 * Math.pow(2, (e.n - 69) / 12);
  const end = when + Math.max(dur, 0.04);
  g.gain.setValueAtTime(0.0001, when); g.gain.linearRampToValueAtTime(amp * v.g, when + v.a);
  g.gain.setValueAtTime(amp * v.g, end); g.gain.linearRampToValueAtTime(0.0001, end + v.r);
  o.connect(g); g.connect(st.out); o.start(when); o.stop(end + v.r + 0.02);
}

function schedule(st) {
  if (!ac || ac.state !== 'running') { st.t0 = null; return; }
  if (st.t0 === null) st.t0 = ac.currentTime + 0.05 - st.pos;           // (re)anchor after resume
  const now = ac.currentTime - st.t0, ahead = now + 0.25, ev = st.song.events;
  while (st.i < ev.length && ev[st.i].t <= ahead) {
    const e = ev[st.i++];
    if (e.ty === 'pc') st.prog[e.ch] = e.v;
    else if (e.ty === 'vol') st.cvol[e.ch] = e.v;
    else if (e.ty === 'on') {
      let dur = 0.25;
      for (let j = st.i; j < ev.length; j++) if (ev[j].ch === e.ch && ev[j].n === e.n && (ev[j].ty === 'off' || ev[j].ty === 'on')) { dur = ev[j].t - e.t; break; }
      if (e.ch === 9) dur = 0.1;
      playNote(st, e, Math.max(st.t0 + e.t, ac.currentTime), dur);
    }
  }
  st.pos = now;
  if (st.i >= ev.length && now > st.song.dur + 0.5) {
    if (st.loops === -1 || --st.loops > 0) { st.i = 0; st.pos = 0; st.t0 = ac.currentTime + 0.05; st.prog = []; st.cvol = []; }
    else stop(st.player);
  }
}
function play(player) {
  stop(player);
  if (!player.bytes || !ensure()) return;
  let song; try { song = parseSMF(player.bytes); } catch (e) { console.warn('midi parse failed', e); return; }
  const out = ac.createGain(); out.gain.value = Math.max(0, Math.min(100, player.level)) / 100; out.connect(master);
  const loops = player.loops === undefined ? 1 : player.loops;
  const st = { player, song, i: 0, pos: 0, t0: null, prog: [], cvol: [], out, loops: loops === 0 ? 1 : loops };
  st.timer = setInterval(() => schedule(st), 60); active.set(player, st); schedule(st);
}
function stop(player) {
  const st = active.get(player); if (!st) return;
  clearInterval(st.timer); active.delete(player);
  try { st.out.gain.cancelScheduledValues(0); st.out.gain.setTargetAtTime(0, ac.currentTime, 0.03); setTimeout(() => st.out.disconnect(), 400); } catch (e) {}
}
window.$rt.audio = { parse: parseSMF, play, stop, setVolume(p, l) { const st = active.get(p); if (st) st.out.gain.value = Math.max(0, Math.min(100, l)) / 100; }, unlock, get ctx() { return ac; }, active };
})();
